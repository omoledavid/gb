<?php $__env->startSection('panel'); ?>
    <div class="row mb-none-30">
        <div class="col-lg-12 col-md-12 mb-30">
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="font-weight-bold"> <?php echo app('translator')->get('Site Title'); ?> </label>
                                    <input class="form-control form-control-lg" type="text" name="sitename" value="<?php echo e($general->sitename); ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="font-weight-bold"><?php echo app('translator')->get('Currency'); ?></label>
                                    <input class="form-control form-control-lg" type="text" name="cur_text" value="<?php echo e($general->cur_text); ?>">
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="font-weight-bold"><?php echo app('translator')->get('Currency Symbol'); ?> </label>
                                    <input class="form-control form-control-lg" type="text" name="cur_sym" value="<?php echo e($general->cur_sym); ?>">
                                </div>
                            </div>

                            <div class="form-group col-md-4">
                                <label class="font-weight-bold"> <?php echo app('translator')->get('Timezone'); ?></label>
                                <select class="select2-basic" name="timezone">
                                    <?php $__currentLoopData = $timezones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timezone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="'<?php echo e(@$timezone); ?>'" <?php if(config('app.timezone') == $timezone): ?> selected <?php endif; ?>><?php echo e(__($timezone)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="font-weight-bold"><?php echo app('translator')->get('OTP Expiration Time'); ?></label>
                                    <div class="input-group">
                                        <input class="form-control form-control-lg" type="text" name="otp_time" value="<?php echo e(getAmount($general->otp_time)); ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text curency-text">
                                                <?php echo app('translator')->get('Seconds'); ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="font-weight-bold"><?php echo app('translator')->get('Account Number Prefex'); ?></label>
                                    <input class="form-control form-control-lg" type="text" name="account_no_prefix" value="<?php echo e($general->account_no_prefix); ?>">
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="font-weight-bold"><?php echo app('translator')->get('Account Number Length'); ?> <code>(<?php echo app('translator')->get('Without Prefix'); ?>)</code></label>
                                    <input class="form-control form-control-lg" type="text" name="account_no_length" value="<?php echo e($general->account_no_length); ?>">
                                </div>
                            </div>

                            <div class="form-group col-md-4">
                                <label class="font-weight-bold"> <?php echo app('translator')->get('Site Base Color'); ?></label>
                                <div class="input-group">
                                <span class="input-group-addon ">
                                    <input type='text' class="form-control form-control-lg colorPicker" value="<?php echo e($general->base_color); ?>"/>
                                </span>
                                    <input type="text" class="form-control form-control-lg colorCode" name="base_color" value="<?php echo e($general->base_color); ?>"/>
                                </div>
                            </div>

                            <div class="form-group col-md-4">
                                <label class="font-weight-bold"> <?php echo app('translator')->get('Site Secondary Color'); ?></label>
                                <div class="input-group">
                                <span class="input-group-addon">
                                    <input type='text' class="form-control form-control-lg colorPicker" value="<?php echo e($general->secondary_color); ?>"/>
                                </span>
                                    <input type="text" class="form-control form-control-lg colorCode" name="secondary_color" value="<?php echo e($general->secondary_color); ?>"/>
                                </div>
                            </div>
                        </div>

                        <h4 class="text-muted my-3 border-bottom pb-2"><?php echo app('translator')->get("Money Transfer Settings Within $general->sitename"); ?></h4>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="font-weight-bold"><?php echo app('translator')->get('Fixed Charge'); ?></label>
                                    <div class="input-group">
                                        <input class="form-control form-control-lg numeric-validation" type="text" name="fixed_transfer_charge" value="<?php echo e(getAmount($general->fixed_transfer_charge)); ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text curency-text">
                                                <?php echo app('translator')->get($general->cur_text); ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="font-weight-bold"><?php echo app('translator')->get('Percent Charge'); ?></label>
                                    <div class="input-group">
                                        <input class="form-control form-control-lg numeric-validation" type="text" name="percent_transfer_charge" value="<?php echo e(getAmount($general->percent_transfer_charge )); ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text"> % </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="font-weight-bold"><?php echo app('translator')->get('Minimum Limit'); ?>/<?php echo app('translator')->get('Transaction'); ?></label>

                                    <div class="input-group">
                                        <input class="form-control form-control-lg numeric-validation" type="text" name="minimum_transfer_limit" value="<?php echo e(getAmount($general->minimum_transfer_limit )); ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text curency-text">
                                                <?php echo app('translator')->get($general->cur_text); ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="font-weight-bold"><?php echo app('translator')->get('Daily Limit'); ?></label>
                                    <div class="input-group">
                                        <input class="form-control form-control-lg numeric-validation" type="text" name="daily_transfer_limit" value="<?php echo e(getAmount($general->daily_transfer_limit )); ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text curency-text">
                                                <?php echo app('translator')->get($general->cur_text); ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label class="font-weight-bold"><?php echo app('translator')->get('Monthly Limit'); ?></label>
                                    <div class="input-group">
                                        <input class="form-control form-control-lg numeric-validation" type="text" name="monthly_transfer_limit" value="<?php echo e(getAmount($general->monthly_transfer_limit )); ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text curency-text">
                                                <?php echo app('translator')->get($general->cur_text); ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="form-group">
                            <button type="submit" class="btn btn--primary btn-block btn-lg"><?php echo app('translator')->get('Update'); ?></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('assets/admin/js/spectrum.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/spectrum.css')); ?>">
<?php $__env->stopPush(); ?>


<?php $__env->startPush('style'); ?>
    <style>
        .sp-replacer {
            padding: 0;
            border: 1px solid rgba(0, 0, 0, .125);
            border-radius: 5px 0 0 5px;
            border-right: none;
        }

        .sp-preview {
            width: 100px;
            height: 46px;
            border: 0;
        }

        .sp-preview-inner {
            width: 110px;
        }

        .sp-dd {
            display: none;
        }
        .select2-container .select2-selection--single {
            height: 44px;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 43px;
        }
        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 43px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            $('.colorPicker').spectrum({
                color: $(this).data('color'),
                change: function (color) {
                    $(this).parent().siblings('.colorCode').val(color.toHexString().replace(/^#?/, ''));
                }
            });

            $('.colorCode').on('input', function () {
                var clr = $(this).val();
                $(this).parents('.input-group').find('.colorPicker').spectrum({
                    color: clr,
                });
            });

            $('input[name=cur_text').on('input', function(){
                $('.curency-text').text($(this).val())
            })

            $('.select2-basic').select2({
                dropdownParent: $('.card-body')
            });

            $('select[name=timezone]').val();
        })(jQuery);

    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\2024\Jan\trustspring\core\resources\views/admin/setting/general.blade.php ENDPATH**/ ?>