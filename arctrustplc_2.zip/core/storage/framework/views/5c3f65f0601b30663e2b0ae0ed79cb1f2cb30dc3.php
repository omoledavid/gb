<?php if(checkIsOtpEnable($general)): ?>
    <div class="form-group mt-0">
        <label for="verification"><?php echo app('translator')->get('Authorization Mode'); ?> *</label>
        <select name="verification" id="verification" class="form--control select" required>
            <option disabled selected value=""><?php echo app('translator')->get('Select One'); ?></option>
            <?php if(auth()->user()->ts): ?>
                <option value="1"><?php echo app('translator')->get('Google Authenticator'); ?></option>
            <?php endif; ?>
            <?php if($general->modules->otp_email): ?>
                <option value="2"><?php echo app('translator')->get('Email'); ?></option>
            <?php endif; ?>
            <?php if($general->modules->otp_sms): ?>
                <option value="3"><?php echo app('translator')->get('Sms'); ?></option>
            <?php endif; ?>
        </select>
    </div>
<?php endif; ?>
<?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/partials/otp_field.blade.php ENDPATH**/ ?>