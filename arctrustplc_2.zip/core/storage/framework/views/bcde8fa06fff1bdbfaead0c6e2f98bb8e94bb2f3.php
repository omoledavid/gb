<?php $__env->startSection('content'); ?>

<?php
    $loginBg     = getContent('login_bg.content', true);
    $links = getContent('pages.element');
?>


<section class="account-section bg_img" style="background-image: url(' <?php echo e(getImage( 'assets/images/frontend/login_bg/' .@$loginBg->data_values->image, '1920x1280')); ?> ');">
    <div class="account-section-left">
        <div class="account-section-left-inner">
          <h2 class="text-white"><?php echo app('translator')->get('Verify Your Email'); ?></h2>
          <p class="text-white mt-3"><?php echo app('translator')->get('A verification code has been sent to your email'); ?> <span class="text--base"><?php echo e(auth()->user()->email); ?></span> <br> <?php echo app('translator')->get('Please check including your Junk/Spam folder.'); ?> <?php echo app('translator')->get("If not found"); ?> <a href="<?php echo e(route('user.send.verify.code')); ?>?type=email" class="text--base fw-bold"><?php echo app('translator')->get('Resend Code'); ?></a></p>
        </div>
    </div>
    <div class="account-section-right">
        <div class="top text-center">
            <a href="<?php echo e(route('home')); ?>" class="account-logo">
                <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="logo">
            </a>
        </div>
        <div class="middle">
          <form class="account-form" method="POST" action="<?php echo e(route('user.verify.email')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="code"><?php echo app('translator')->get('Verification Code'); ?> <span class="text--danger">*</span></label>
              <input type="text" name="email_verified_code" placeholder="<?php echo app('translator')->get('Code'); ?>" class="form--control" maxlength="7" id="code" autocomplete="off" required>
            </div>

          <?php if($errors->has('resend')): ?>
            <small class="text-danger"><?php echo e($errors->first('resend')); ?></small>
          <?php endif; ?>

            <button type="submit" class="btn btn--base w-100"><?php echo app('translator')->get('Submit'); ?></button>

          </form>
        </div>
        <div class="bottom">
            <div class="row">
                <div class="col-xl-12">
                    <ul class="d-flex flex-wrap align-items-center account-short-link justify-content-center">
                            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('page', [$link->id,slug($link->data_values->title)])); ?>" target="blank">
                        <?php echo e(__($link->data_values->title)); ?></a>
                        <?php echo e($loop->last ? '.' : ','); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    (function($){
        "use strict";
        $('#code').on('input change', function () {
          var xx = document.getElementById('code').value;

              $(this).val(function (index, value) {
                 value = value.substr(0,7);
                  return value.replace(/\W/gi, '').replace(/(.{3})/g, '$1 ');
              });

      });
    })(jQuery)
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate .'layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/auth/authorization/email.blade.php ENDPATH**/ ?>