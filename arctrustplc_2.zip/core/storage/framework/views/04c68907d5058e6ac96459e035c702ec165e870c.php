<!-- meta tags and other links -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($general->sitename($pageTitle ?? '')); ?></title>
    <?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- bootstrap 5  -->
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue. 'css/lib/bootstrap.min.css')); ?>">
    <!-- fontawesome 5  -->
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue. 'css/all.min.css')); ?>">
    <!-- lineawesome font -->
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue. 'css/line-awesome.min.css')); ?>">
    <!-- slick slider css -->
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue. 'css/lib/slick.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue. 'css/lightcase.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue. 'css/custom.css')); ?>">

    <!-- main css -->
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue. 'css/main.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue.'css/color.php?color='.$general->base_color.'&secondColor='.$general->secondary_color)); ?>">

    <?php echo $__env->yieldPushContent('style-lib'); ?>

    <?php echo $__env->yieldPushContent('style'); ?>

</head>

<body>
    <div class="preloader">
        <div class="dl">
            <div class="dl__container">
            <div class="dl__corner--top"></div>
            <div class="dl__corner--bottom"></div>
            </div>
            <div class="dl__square"></div>
        </div>
    </div>


    <?php echo $__env->make($activeTemplate.'partials.auth_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="main-wrapper">

        <?php if(!request()->routeIs('home')): ?>
        <?php echo $__env->make($activeTemplate.'partials.breadcumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make($activeTemplate.'partials.bottom_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <section class="pt-100 pb-100 bg_img" style="background-image: url(' <?php echo e(asset($activeTemplateTrue.'images/elements/bg1.jpg')); ?> ');">
            <?php echo $__env->yieldContent('content'); ?>
        </section>

    </div>

    <?php echo $__env->yieldPushContent('modal'); ?>

    <?php echo $__env->make($activeTemplate.'partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- jQuery library -->
    <script src="<?php echo e(asset($activeTemplateTrue . 'js/lib/jquery-3.5.1.min.js')); ?>"></script>

    <script src="<?php echo e(asset($activeTemplateTrue . 'js/lightcase.js')); ?>"></script>

    <!-- bootstrap js -->
    <script src="<?php echo e(asset($activeTemplateTrue . 'js/lib/bootstrap.bundle.min.js')); ?>"></script>
    <!-- slick slider js -->
    <script src="<?php echo e(asset($activeTemplateTrue . 'js/lib/slick.min.js')); ?>"></script>
    <!-- scroll animation -->
    <script src="<?php echo e(asset($activeTemplateTrue . 'js/lib/wow.min.js')); ?>"></script>
    <!-- main js -->
    <script src="<?php echo e(asset($activeTemplateTrue . 'js/app.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('script-lib'); ?>

    <?php echo $__env->make('partials.plugins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('script'); ?>

    <script>
        (function ($) {
            "use strict";
            $(".langSel").on("change", function () {
                window.location.href = "<?php echo e(url('/')); ?>/change/" + $(this).val();
            });
        })(jQuery);
    </script>

</body>

</html>
<?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/layouts/master.blade.php ENDPATH**/ ?>