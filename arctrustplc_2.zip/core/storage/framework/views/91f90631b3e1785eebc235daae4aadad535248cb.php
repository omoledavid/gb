<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="custom--card">
            <div class="table-responsive--md mt-3">
                <table class="table custom--table">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->get('TRX'); ?></th>
                            <th><?php echo app('translator')->get('Account Name'); ?></th>
                            <th><?php echo app('translator')->get('Account Number'); ?></th>
                            <th><?php echo app('translator')->get('Bank'); ?></th>
                            <th><?php echo app('translator')->get('Amount'); ?></th>
                            <th><?php echo app('translator')->get('Status'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('TRX'); ?>">
                                <?php echo e($transfer->trx); ?>

                            </td>

                            <td data-label="<?php echo app('translator')->get('Account Name'); ?>">
                                <?php echo e($transfer->beneficiary->account_name); ?>

                            </td>

                            <td data-label="<?php echo app('translator')->get('Account Number'); ?>">
                                <?php echo e($transfer->beneficiary->account_number); ?>

                            </td>

                            <td data-label="<?php echo app('translator')->get('Bank'); ?>">
                                <?php echo e($transfer->bank->name??$general->sitename); ?>

                            </td>


                            <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                <?php echo e($general->cur_sym.showAmount($transfer->amount)); ?>

                            </td>

                            <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                <?php if($transfer->status == 1): ?>
                                <span class="badge badge--success">
                                    <?php echo app('translator')->get('Completed'); ?>
                                </span>
                                <?php elseif($transfer->status == 0): ?>
                                <span class="badge badge--warning">
                                    <?php echo app('translator')->get('Pending'); ?>
                                </span>
                                <?php elseif($transfer->status == 2): ?>
                                    <span class="badge badge--danger">
                                        <?php echo app('translator')->get('Rejected'); ?>
                                    </span>
                                <?php endif; ?>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100%" class="text-center"><?php echo app('translator')->get($emptyMessage); ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php echo e($transfers->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('bottom-menu'); ?>
    <?php if($general->modules->own_bank || $general->modules->other_bank): ?>
        <li>
            <a href="<?php echo e(route('user.transfer.beneficiary.manage')); ?>"><?php echo app('translator')->get('Beneficiary Management'); ?></a>
        </li>
        <?php if($general->modules->own_bank): ?>
            <li>
                <a href="<?php echo e(route('user.transfer.own')); ?>"><?php echo app('translator')->get('Transfer Within'); ?> <?php echo app('translator')->get($general->sitename); ?></a>
            </li>
        <?php endif; ?>
        <?php if($general->modules->other_bank): ?>
            <li><a href="<?php echo e(route('user.transfer.other')); ?>"><?php echo app('translator')->get('Transfer To Other Bank'); ?></a></li>
        <?php endif; ?>

        <li>
            <a class="active" href="<?php echo e(route('user.transfer.history')); ?>"><?php echo app('translator')->get('Transfer History'); ?></a>
        </li>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/transfers/history.blade.php ENDPATH**/ ?>