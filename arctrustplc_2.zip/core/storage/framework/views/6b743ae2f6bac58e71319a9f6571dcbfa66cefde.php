<?php $__env->startSection('content'); ?>

<?php
    $loginBg     = getContent('login_bg.content', true);
    $links = getContent('pages.element');
?>

<section class="account-section bg_img" style="background-image: url(' <?php echo e(getImage( 'assets/images/frontend/login_bg/' .@$loginBg->data_values->image, '1920x1280')); ?> ');">
    <div class="account-section-left">
        <div class="account-section-left-inner">
            <h4 class="title text-white mb-2"><?php echo e(__(@$loginBg->data_values->heading)); ?></h4>
            <p class="text-white"><?php echo e(__(@$loginBg->data_values->subheading)); ?></p>

            <p class="mt-xl-5 mt-3 text-white"><?php echo app('translator')->get("Haven't an account"); ?>? <a href="<?php echo e(route('user.register')); ?>" class="text--base"><?php echo app('translator')->get('Signup here'); ?></a></p>
        </div>
    </div>
    <div class="account-section-right">
        <div class="top text-center">
            <a href="<?php echo e(route('home')); ?>" class="account-logo">
                <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="logo">
            </a>
        </div>
        <div class="middle">
            <form class="account-form" method="POST" action="<?php echo e(route('user.login')); ?>"
                onsubmit="return submitUserForm();">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="username"><?php echo app('translator')->get('Username or Email'); ?> *</label>
                    <input type="text" name="username" value="<?php echo e(old('username')); ?>"
                        placeholder="<?php echo app('translator')->get('Username or Email'); ?>" class="form--control" required>
                </div>
                <div class="form-group">
                    <label for="password"><?php echo app('translator')->get('Password'); ?> *</label>
                    <input id="password" type="password" placeholder="Password" class="form--control"
                        name="password" required autocomplete="current-password" required>
                </div>

                <div class="row">
                    <div class="col-md-7">
                        <div class="form-check custom--checkbox">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="remember">
                                <?php echo app('translator')->get('Remember Me'); ?>
                            </label>
                        </div>
                    </div>
                    <div class="col-md-5 text-md-end">
                        <a href="<?php echo e(route('user.password.request')); ?>" class="custom--cl">
                            <?php echo app('translator')->get('Forgot password'); ?>?
                        </a>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-12">
                        <?php echo loadReCaptcha() ?>
                    </div>
                </div>
                <?php echo $__env->make($activeTemplate.'partials.custom_captcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <button type="submit" class="btn btn--base w-100"><?php echo app('translator')->get('Sign In'); ?></button>
            </form>
        </div>
        <div class="bottom">
            <div class="row">
                <div class="col-xl-12">
                    <ul class="d-flex flex-wrap align-items-center account-short-link justify-content-center">
                            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('page', [$link->id,slug($link->data_values->title)])); ?>" target="blank">
                        <?php echo e(__($link->data_values->title)); ?></a>
                        <?php echo e($loop->last ? '.' : ','); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";

        function submitUserForm() {
            var response = grecaptcha.getResponse();
            if (response.length == 0) {
                document.getElementById('g-recaptcha-error').innerHTML =
                    '<span style="color:red;"><?php echo app('translator')->get("Captcha field is required."); ?></span>';
                return false;
            }
            return true;
        }

        function verifyCaptcha() {
            document.getElementById('g-recaptcha-error').innerHTML = '';
        }

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/auth/login.blade.php ENDPATH**/ ?>