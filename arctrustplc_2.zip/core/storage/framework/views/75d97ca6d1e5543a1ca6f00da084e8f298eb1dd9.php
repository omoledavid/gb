<?php $__env->startSection('content'); ?>

<?php
    $forgetPass = getContent('forget_pass.content', true);
    $links = getContent('pages.element');
?>

<section class="account-section bg_img" style="background-image: url(' <?php echo e(getImage( 'assets/images/frontend/forget_pass/' .@$forgetPass->data_values->image, '1920x1280')); ?> ');">
    <div class="account-section-left">
        <div class="account-section-left-inner">
            <h2 class="title text-white mb-2"><?php echo e(__(@$forgetPass->data_values->heading)); ?></h2>
            <p class="text-white"><?php echo e(__(@$forgetPass->data_values->subheading)); ?></p>
        </div>
    </div>
    <div class="account-section-right">
        <div class="top text-center">
            <a href="<?php echo e(route('home')); ?>" class="account-logo">
                <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="logo">
            </a>
        </div>
        <div class="middle">
            <form class="account-form" method="POST" action="<?php echo e(route('user.password.email')); ?>">
              <?php echo csrf_field(); ?>
              <div class="form-group">
              <label for="type"><?php echo app('translator')->get('My'); ?></label>
                  <select class="select" name="type" id="type">
                      <option value="email"><?php echo app('translator')->get('E-Mail Address'); ?></option>
                      <option value="username"><?php echo app('translator')->get('Username'); ?></option>
                  </select>
              </div>
              <div class="form-group">
              <label class="my_value"></label>
              <input type="text" class="form--control <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="value" value="<?php echo e(old('value')); ?>" required autofocus="off">
              </div>
              <button type="submit" class="btn btn--base w-100"><?php echo app('translator')->get('Submit'); ?></button>
          </form>
        </div>
        <div class="bottom">
            <div class="row">
                <div class="col-xl-12">
                    <ul class="d-flex flex-wrap align-items-center account-short-link justify-content-center">
                            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('page', [$link->id,slug($link->data_values->title)])); ?>" target="blank">
                        <?php echo e(__($link->data_values->title)); ?></a>
                        <?php echo e($loop->last ? '.' : ','); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>

    (function($){
        "use strict";

        myVal();
        $('select[name=type]').on('change',function(){
            myVal();
        });
        function myVal(){
            $('.my_value').text($('select[name=type] :selected').text());
        }
    })(jQuery)
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('templates.basic.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/auth/passwords/email.blade.php ENDPATH**/ ?>