<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card border--dark">
                <h5 class="card-header bg--dark p-2"><?php echo app('translator')->get('User\'s Required Information'); ?></h5>

                <form action="" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="card-body">
                        <div class="addedField">
                            <?php if($fieldsCount): ?>
                                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="user-data border mb-3">
                                                <button class="btn--danger removeBtn mb-1" type="button">
                                                    <i class="fa fa-times"></i>
                                                </button>
                                                <div class="d-flex flex-wrap">
                                                    <div class="w-50">
                                                        <input name="input_form[<?php echo e($loop->index); ?>][field_name]" class="form-control rounded-0" type="text" value="<?php echo e($v->field_name); ?>" required placeholder="<?php echo app('translator')->get('Field Name'); ?>">
                                                    </div>
                                                    <div class="w-25">
                                                        <select name="input_form[<?php echo e($loop->index); ?>][type]" class="form-control rounded-0">
                                                            <option value="text" <?php if($v->type == 'text'): ?> selected <?php endif; ?>>
                                                                <?php echo app('translator')->get('Input Text'); ?>
                                                            </option>
                                                            <option value="textarea" <?php if($v->type == 'textarea'): ?> selected <?php endif; ?>>
                                                                <?php echo app('translator')->get('Textarea'); ?>
                                                            </option>
                                                            <option value="file" <?php if($v->type == 'file'): ?> selected <?php endif; ?>>
                                                                <?php echo app('translator')->get('File upload'); ?>
                                                            </option>
                                                        </select>
                                                    </div>
                                                    <div class="w-25">
                                                        <select name="input_form[<?php echo e($loop->index); ?>][validation]" class="form-control rounded-0">
                                                            <option value="required" <?php if($v->validation == 'required'): ?> selected <?php endif; ?>> <?php echo app('translator')->get('Required'); ?> </option>
                                                            <option value="nullable" <?php if($v->validation == 'nullable'): ?> selected <?php endif; ?>>  <?php echo app('translator')->get('Optional'); ?> </option>
                                                        </select>
                                                    </div>

                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                        </div>

                        <button type="button" class="btn btn-sm btn--success addUserData">
                            <i class="la la-fw la-plus"></i><?php echo app('translator')->get('Add More'); ?>
                        </button>
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-block btn--primary"> <?php echo app('translator')->get('Save'); ?> </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    (function ($) {
        "use strict";
        let addCount = <?php echo e($fieldsCount); ?>;

        $('.addUserData').on('click', function () {
            var html = `
                    <div class="user-data border mb-3">
                        <button class="btn--danger removeBtn mb-1" type="button">
                            <i class="fa fa-times"></i>
                        </button>

                        <div class="d-flex flex-wrap">
                            <div class="w-50">
                                <input name="input_form[${addCount}][field_name]" class="form-control rounded-0" type="text" value="" required placeholder="<?php echo app('translator')->get('Field Name'); ?>">
                            </div>

                            <div class="w-25">
                                <select name="input_form[${addCount}][type]" class="form-control rounded-0">
                                    <option value="text"> <?php echo app('translator')->get('Input'); ?> </option>
                                    <option value="textarea" > <?php echo app('translator')->get('Textarea'); ?> </option>
                                    <option value="file"> <?php echo app('translator')->get('File upload'); ?> </option>
                                </select>
                            </div>


                            <div class="w-25">
                                <select name="input_form[${addCount}][validation]"
                                        class="form-control rounded-0">
                                    <option value="required"> <?php echo app('translator')->get('Required'); ?> </option>
                                    <option value="nullable">  <?php echo app('translator')->get('Optional'); ?> </option>
                                </select>
                            </div>
                        </div>
                    </div>`;

            $('.addedField').append(html);

            addCount++;

            changeButtonText();
        });



        function changeButtonText() {
            let count = $(document).find('.user-data').length
            if (count > 0) {
                $('.addUserData').html(`<i class="la la-fw la-plus"></i><?php echo app('translator')->get('Add More'); ?>`)
            } else {
                $('.addUserData').html(`<i class="la la-fw la-plus"></i><?php echo app('translator')->get('Add Fields'); ?>`)
            }
        }

        $(document).on('click', '.removeBtn', function () {
            $(this).closest('.user-data').remove();
            changeButtonText();
        });

        changeButtonText();
    })(jQuery);

</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
<style>
    .user-data {
        position: relative !important;
        border-radius: 5px;
    }

    .removeBtn {
        position: absolute;
        left: -5px;
        top: -5px;
        width: 20px;
        height: 20px;
        font-size: 10px;
        border-radius: 50%;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\2024\Jan\trustspring\core\resources\views/admin/setting/kyc.blade.php ENDPATH**/ ?>