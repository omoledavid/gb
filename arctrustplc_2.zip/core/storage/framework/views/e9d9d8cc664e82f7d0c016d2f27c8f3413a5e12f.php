
<?php
    $testimonials   = getContent('testimonial.element');
?>
<?php if($testimonials->count()): ?>
<section class="testimonial-section pt-50 pb-100">
    <div class="container">
        <div class="testimonial-slider wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-slide">
                <div class="testimonial-item">
                    <div class="ratings">
                        <?php echo displayRating(floatval($testimonial->data_values->rating)) ?>
                    </div>
                    <p class="text-white mt-2"><?php echo e(__($testimonial->data_values->quote)); ?></p>
                    <div class="d-flex align-items-center mt-4">
                    <h4 class="name text-white"><?php echo e(__($testimonial->data_values->name)); ?></h4>
                    <span class="designation text-white-50 ms-3 fs--14px"><?php echo e(__($testimonial->data_values->designation)); ?></span>
                    </div>
                </div><!-- testimonial-item end -->
            </div><!-- single-slide end -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/sections/testimonial.blade.php ENDPATH**/ ?>