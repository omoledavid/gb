<?php $__env->startSection('panel'); ?>
    <div class="row">

        <div class="col-lg-12">
            <div class="card">
                <div class="card-body p-0">
                    <div class="table-responsive--lg table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('Loan No. | Plan'); ?></th>
                                    <th><?php echo app('translator')->get('User'); ?></th>
                                    <th><?php echo app('translator')->get('Amount'); ?></th>
                                    <th><?php echo app('translator')->get('Installment Amount'); ?></th>
                                    <th><?php echo app('translator')->get('Installment'); ?></th>
                                    <th><?php echo app('translator')->get('Next Installment'); ?></th>
                                    <th><?php echo app('translator')->get('Status'); ?></th>
                                    <th><?php echo app('translator')->get('Action'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td data-label="<?php echo app('translator')->get('Loan No. | Plan'); ?>">
                                            <span class="font-weight-bold"><?php echo e(__($loan->trx)); ?></span>
                                            <span class="d-block text--info"><?php echo e(__($loan->plan->name)); ?></span>
                                        </td>

                                        <td data-label="<?php echo app('translator')->get('User'); ?>">
                                            <span class="font-weight-bold d-block"><?php echo e($loan->user->fullname); ?></span>
                                            <span class="small">
                                            <a href="<?php echo e(route('admin.users.detail', $loan->user_id)); ?>"><span>@</span><?php echo e($loan->user->username); ?></a>
                                            </span>
                                        </td>

                                        <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                            <span>
                                                <?php echo e($general->cur_sym.showAmount($loan->amount)); ?>

                                            </span>
                                            <span class="d-block text--info">
                                                <?php echo e($general->cur_sym.showAmount($loan->final_amount)); ?> <?php echo app('translator')->get('Receivable'); ?>
                                            </span>

                                        </td>

                                        <td data-label="<?php echo app('translator')->get('Installment Amount'); ?>">
                                            <span><?php echo e($general->cur_sym.showAmount($loan->per_installment)); ?></span>
                                            <span class="d-block text--info">
                                                <?php echo app('translator')->get("per"); ?> <?php echo e($loan->installment_interval); ?> <?php echo app('translator')->get("days"); ?>
                                            </span>
                                        </td>

                                        <td data-label="<?php echo app('translator')->get('Installment'); ?>">
                                            <span>
                                                <?php echo app('translator')->get('Total'); ?> : <?php echo e($loan->total_installment); ?>

                                            </span>
                                            <span class="d-block text--info">
                                                <?php echo app('translator')->get('Given'); ?> : <?php echo e($loan->given_installment); ?>

                                            </span>
                                        </td>


                                        <td data-label="<?php echo app('translator')->get('Next Installment'); ?>">
                                            <?php if($loan->next_installment_date): ?>
                                            <span><?php echo e(showDateTime($loan->next_installment_date, 'd M, Y')); ?></span>
                                            <span class="d-block text--info">
                                                <?php echo e(diffForHumans($loan->next_installment_date, 'd M, Y')); ?>

                                            </span>
                                            <?php else: ?>
                                            <?php echo app('translator')->get('...'); ?>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                            <?php if($loan->status == 0): ?>
                                                <span class="badge badge--dark"><?php echo app('translator')->get('Pending'); ?></span>
                                            <?php elseif($loan->status == 1): ?>
                                                <span class="badge badge--warning"><?php echo app('translator')->get('Running'); ?></span>
                                            <?php elseif($loan->status == 2): ?>
                                                <span class="badge badge--success"><?php echo app('translator')->get('Paid'); ?></span>

                                            <?php elseif($loan->status == 3): ?>
                                                <span class="badge badge--danger"><?php echo app('translator')->get('Rejected'); ?></span>
                                                <span class="admin-feedback" data-feedback="<?php echo e(__($loan->admin_feedback)); ?>"><i class="fas fa-info-circle"></i></span>
                                            <?php endif; ?>
                                        </td>

                                        <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                            <a href="<?php echo e(route('admin.loan.details', $loan->id)); ?>" class="icon-btn">
                                                <i class="las la-desktop"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="100%" class="text-center"><?php echo e(__($emptyMessage)); ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
                <?php if($loans->hasPages()): ?>
                    <div class="card-footer py-4">
                    <?php echo e(paginateLinks($loans)); ?>

                    </div>
                <?php endif; ?>
            </div><!-- card end -->
        </div>
    </div>



<div id="statusModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo app('translator')->get('Confirmation'); ?>!</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('admin.loan.plan.status')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                <div class="modal-body">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('No'); ?></button>
                    <button type="submit" class="btn btn--primary"><?php echo app('translator')->get('Yes'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    (function ($) {

        "use strict";

        $('.statusBtn').on('click', (e)=> {
            var btn     = $(e.currentTarget);
            var modal   = $('#statusModal');
            var status  = btn.data('status');
            var message = status == 1 ? '<?php echo app('translator')->get("Are you sure to disable this plan?"); ?>':'<?php echo app('translator')->get("Are you sure to enable this plan?"); ?>';
            modal.find('.modal-body').text(message);
            modal.find('input[name=id]').val(btn.data('id'));
            modal.modal('show');
        });

    })(jQuery);
</script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('breadcrumb-plugins'); ?>
    <form action="" method="GET" class="form-inline float-sm-right bg--white">
        <div class="input-group has_append">
            <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('Loan No.'); ?>" value="<?php echo e(request()->search ?? ''); ?>">
            <div class="input-group-append">
                <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
            </div>
        </div>
    </form>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/admin/loan/index.blade.php ENDPATH**/ ?>