<?php $__env->startSection('content'); ?>
    <div class="container">
        <form class="register" action="" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row justify-content-center gy-4">

            <div class="col-xl-4 col-lg-5">
                <div class="card">
                    <div class="card-body">
                        <div class="avatar-upload">
                            <div class="avatar-edit">
                                <input type='file' name="image" id="imageUpload" accept=".png, .jpg, .jpeg" />
                                <label for="imageUpload"></label>
                            </div>
                            <div class="avatar-preview">
                                <div id="imagePreview" style="background-image: url(<?php echo e(getImage(imagePath()['profile']['user']['path'].'/'. $user->image,imagePath()['profile']['user']['size'])); ?>);">
                                </div>
                            </div>
                        </div>
                        <ul class="caption-list-two">
                            <li>
                                <span class="caption"><?php echo app('translator')->get('Name'); ?></span>
                                <span class="value"><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></span>
                            </li>
                            <li>
                                <span class="caption"><?php echo app('translator')->get('E-mail Address'); ?></span>
                                <span class="value"><?php echo e($user->email); ?></span>
                            </li>
                            <li>
                                <span class="caption"><?php echo app('translator')->get('Mobile Number'); ?></span>
                                <span class="value"><?php echo e($user->mobile); ?></span>
                            </li>
                            <li>
                                <span class="caption"><?php echo app('translator')->get('Country'); ?></span>
                                <span class="value"><?php echo e($user->address->country); ?></span>
                            </li>
                            <li>
                                <span class="caption"><?php echo app('translator')->get('City'); ?></span>
                                <span class="value"><?php echo e($user->address->city); ?></span>
                            </li>
                            <li>
                                <span class="caption"><?php echo app('translator')->get('Zip Code'); ?></span>
                                <span class="value"><?php echo e($user->address->zip); ?></span>
                            </li>
                            <li>
                                <span class="caption"><?php echo app('translator')->get('Address'); ?></span>
                                <span class="value"><?php echo e(@$user->address->address); ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xl-8 col-lg-7">
                <div class="card">
                    <div class="card-body p-4">
                        <div class="row">
                            <div class="form-group col-12">
                                <label for="InputFirstname" class="col-form-label"><?php echo app('translator')->get('First Name'); ?>:</label>
                                <input type="text" class="form--control" id="InputFirstname" name="firstname" placeholder="<?php echo app('translator')->get('First Name'); ?>" value="<?php echo e($user->firstname); ?>" >
                            </div>
                            <div class="form-group col-12">
                                <label for="lastname" class="col-form-label"><?php echo app('translator')->get('Last Name'); ?>:</label>
                                <input type="text" class="form--control" id="lastname" name="lastname" placeholder="<?php echo app('translator')->get('Last Name'); ?>" value="<?php echo e($user->lastname); ?>">
                            </div>
                            <div class="form-group ">
                                <button type="submit" class="btn btn--base w-100"><?php echo app('translator')->get('Update Profile'); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style-lib'); ?>
    <link href="<?php echo e(asset($activeTemplateTrue.'css/bootstrap-fileinput.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/build/css/intlTelInput.css')); ?>">
    <style>
        .intl-tel-input {
            position: relative;
            display: inline-block;
            width: 100%;!important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                    $('#imagePreview').hide();
                    $('#imagePreview').fadeIn(650);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imageUpload").change(function() {
            readURL(this);
        });

    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('bottom-menu'); ?>

<li><a class="active" href="<?php echo e(route('user.profile.setting')); ?>"><?php echo app('translator')->get('Profile'); ?></a></li>
<?php if($general->modules->referral_system): ?>
<li><a href="<?php echo e(route('user.referral.users')); ?>"><?php echo app('translator')->get('Referral'); ?></a></li>
<?php endif; ?>
<li><a href="<?php echo e(route('user.twofactor')); ?>"><?php echo app('translator')->get('2FA Security'); ?></a></li>
<li><a href="<?php echo e(route('user.change.password')); ?>"><?php echo app('translator')->get('Change Password'); ?></a></li>
<li><a href="<?php echo e(route('user.transaction.history')); ?>"><?php echo app('translator')->get('Transactions'); ?></a></li>
<li><a class="<?php echo e(menuActive(['ticket.*'])); ?>" href="<?php echo e(route('ticket')); ?>"><?php echo app('translator')->get('Support Tickets'); ?></a></li>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/profile_setting.blade.php ENDPATH**/ ?>