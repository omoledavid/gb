<?php
    $pricing    = getContent('fdr_plans.content', true);
    $plans      = App\Models\FdrPlan::active()->latest()->limit(3)->get();
?>

<?php if($plans->count()): ?>
<section class="pt-50 pb-100">
    <div class="container">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-10">
                <div class="section-header text-center">
                    <div class="section-top-title border-left custom--cl"><?php echo e(__(@$pricing->data_values->heading)); ?></div>
                    <h2 class="section-title"><?php echo e(__(@$pricing->data_values->subheading)); ?></h2>
                </div>
                </div>
            </div><!-- row end -->
            <div class="row justify-content-center gy-4">
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="plan-card rounded-3 wow fadeInUp gy-3">
                            <span class="fdr-badge"><?php echo app('translator')->get('FDR'); ?></span>
                            <div class="plan-card__header">
                                <div class="wave-shape"><img src="<?php echo e(asset($activeTemplateTrue. 'images/elements/wave.png')); ?>" alt="img"></div>
                            <h4 class="plan-name"><?php echo e(__($plan->name)); ?></h4>
                            <div class="plan-price"><?php echo e(getAmount($plan->interest_rate)); ?>%<sub>/ <?php echo e($plan->interest_interval); ?> <?php echo app('translator')->get('Days'); ?></sub></div>
                            </div>
                            <div class="plan-card__body text-center">
                                <ul class="plan-feature-list">
                                    <li class="d-flex flex-wrap justify-content-between">
                                        <span><?php echo app('translator')->get('Lock in Period'); ?></span>
                                        <?php echo e($plan->locked_days); ?> <?php echo app('translator')->get('Days'); ?>
                                    </li>

                                    <li class="d-flex flex-wrap justify-content-between">
                                        <span><?php echo app('translator')->get('Get Profit'); ?> <?php echo app('translator')->get('Every'); ?></span>
                                        <?php echo e($plan->interest_interval); ?> <?php echo app('translator')->get('Days'); ?>
                                    </li>

                                    <li class="d-flex flex-wrap justify-content-between">
                                        <span><?php echo app('translator')->get('Profit Rate'); ?></span>
                                        <?php echo e(getAmount($plan->interest_rate)); ?>%
                                    </li>

                                    <li class="d-flex flex-wrap justify-content-between">
                                        <span><?php echo app('translator')->get('Minimum'); ?> </span>
                                        <?php echo e($general->cur_sym); ?><?php echo e(showAmount($plan->minimum_amount)); ?>

                                    </li>
                                    <li class="d-flex flex-wrap justify-content-between">
                                        <span><?php echo app('translator')->get('Maximum'); ?></span>
                                        <?php echo e($general->cur_sym); ?><?php echo e(showAmount($plan->maximum_amount)); ?>

                                    </li>
                                </ul>
                            </div>
                            <div class="plan-card__footer text-center">
                                <?php if(auth()->guard()->check()): ?>
                                    <button type="button" data-id="<?php echo e($plan->id); ?>" data-minimum="<?php echo e($general->cur_sym); ?><?php echo e(showAmount($plan->minimum_amount)); ?>" data-maximum="<?php echo e($general->cur_sym); ?><?php echo e(showAmount($plan->maximum_amount)); ?>" class="btn btn-md w-100 btn--base fdrBtn"><?php echo app('translator')->get('Apply Now'); ?></button>
                                <?php else: ?>
                                    <a href="<?php echo e(route('user.login')); ?>" class="btn btn-md w-100 btn--base"><?php echo app('translator')->get('Apply Now'); ?></a>
                                <?php endif; ?>
                            </div>
                        </div><!-- plan-card end -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-12 d-flex justify-content-center">
                    <a href="<?php echo e(route('user.fdr.plans')); ?>" class="btn btn--base"><?php echo app('translator')->get('View More'); ?></a>
                </div>
            </div>

        </div>
    </div>
</section>

<?php if(auth()->guard()->check()): ?>
    <?php $__env->startPush('modal'); ?>
        <div class="modal fade" id="fdrModal">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <strong class="modal-title method-name" id="exampleModalLabel"><?php echo app('translator')->get('Apply to Open an FDR'); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </a>
                    </div>
                    <form action="<?php echo e(route('user.action')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <input type="hidden" name="id">
                            <input type="hidden" name="type" value="fdr">
                            <div class="form-group mt-0">
                                <label for="amount"><?php echo app('translator')->get('Amount'); ?> *</label>
                                <input type="text" id="amount" name="amount" class="form--control integer-validation" required>
                                <p><small class="text--danger min-limit mt-2"></small></p>
                                <p><small class="text-danger max-limit"></small></p>
                            </div>


                            <?php if(checkIsOtpEnable($general)): ?>
                                <?php echo $__env->make($activeTemplate.'partials.otp_field', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-md btn-danger text-white" data-bs-dismiss="modal"><?php echo app('translator')->get('Cancel'); ?></button>
                            <button type="submit" class="btn btn-md custom--bg text-white"><?php echo app('translator')->get('Submit'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            $('.fdrBtn').on('click', (e)=> {
                var modal   = $('#fdrModal');
                var button  = $(e.currentTarget);
                modal.find('input[name=id]').val(button.data('id'));
                modal.find('.min-limit').text(`Minimum Amount ${button.data('minimum')}`);
                modal.find('.max-limit').text(`Maximum Amount ${button.data('maximum')}`);
                modal.modal('show');
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php endif; ?>
<?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/sections/fdr_plans.blade.php ENDPATH**/ ?>