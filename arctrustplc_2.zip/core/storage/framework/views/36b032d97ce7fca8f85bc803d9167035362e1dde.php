<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($general->kyc_form): ?>
            <div class="row justify-content-center mt-4">
                <div class="col-md-8">
                    <div class="card border border--base">
                        <div class="card-header bg--base">
                            <h5 class="card-title m-0 p-2 text-white"><?php echo app('translator')->get('Change Your Password'); ?></h5>
                        </div>
                        <div class="card-body">
                            <form action="" method="post" class="register" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php $__currentLoopData = $general->kyc_form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->type == 'text'): ?>
                                        <div class="form-group">
                                            <label>
                                                <?php echo app('translator')->get($item->field_name); ?>
                                                <?php if($item->validation == "required"): ?>
                                                <span class="text--danger">*</span>
                                                <?php endif; ?>
                                            </label>
                                            <input type="text" name="<?php echo e(snakeCase($item->field_name)); ?>" class="form--control" <?php echo e($item->validation); ?>>
                                        </div>
                                    <?php elseif($item->type == 'textarea'): ?>
                                        <div class="form-group">
                                            <label>
                                                <?php echo app('translator')->get($item->field_name); ?>
                                                <?php if($item->validation == "required"): ?>
                                                <span class="text--danger">*</span>
                                                <?php endif; ?>
                                            </label>
                                            <textarea type="text" name="<?php echo e(snakeCase($item->field_name)); ?>"  class="form--control" <?php echo e($item->validation); ?>></textarea>
                                        </div>
                                    <?php elseif($item->type == 'file'): ?>
                                        <div class="form-group">
                                            <label>
                                                <?php echo app('translator')->get($item->field_name); ?>
                                                <?php if($item->validation == "required"): ?>
                                                <span class="text--danger">*</span>
                                                <?php endif; ?>
                                            </label>
                                            <input type="file" name="<?php echo e(snakeCase($item->field_name)); ?>" class="form--control" accept=".jpg,.jpeg,.png" <?php echo e($item->validation); ?>>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <button type="submit" class="btn btn--base w-100"><?php echo app('translator')->get('Submit'); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/kyc/form.blade.php ENDPATH**/ ?>