<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card border border--base p-lg-4 border--base beneficiary-card">
                <div class="card-body">
                    <ul class="nav nav-tabs mb-3">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" data-name="own" data-bs-toggle="pill" data-bs-target="#own-bank" type="button" role="tab"><?php echo app('translator')->get($general->sitename); ?></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-name="other" data-bs-toggle="pill" data-bs-target="#other-bank" type="button" role="tab"><?php echo app('translator')->get('Other Banks'); ?></button>
                        </li>
                    </ul>
                    <div class="tab-content">

                        
                        <div class="tab-pane fade show active" id="own-bank" role="tabpanel">

                            <div class="my-3 d-flex justify-content-end">
                              <button type="button" class="btn btn-sm btn--base add-btn"> <i class="fas fa-plus-circle"></i> <?php echo app('translator')->get('Add Beneficiary'); ?></button>
                            </div>

                            <div class="card border mb-3 d-none" id="addForm">
                                <div class="card-body p-4">
                                    <form action="<?php echo e(route('user.transfer.beneficiary.own.add')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <h4><?php echo app('translator')->get('Add Beneficiary to'); ?> <?php echo app('translator')->get($general->sitename); ?></h4>
                                            <button type="button" class="btn btn-sm btn--danger close-form-btn"><i class="fas fa-times-circle"></i></button>
                                        </div>
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get('Account Number'); ?> <span class="text--danger">*</span></label>
                                            <input type="text" name="account_number" class="form--control">
                                            <small class="text--danger error-message"></small>
                                        </div>
                                        <div class="form-group">
                                          <label><?php echo app('translator')->get('Account Name'); ?> <span class="text--danger">*</span></label>
                                          <input type="text" name="account_name" class="form--control">
                                        </div>
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get('Short Name'); ?> <span class="text--danger">*</span></label>
                                            <input type="text" name="short_name" class="form--control">
                                        </div>
                                        <button type="submit" class="btn w-100 btn--base"><?php echo app('translator')->get('Submit'); ?></button>
                                    </form>
                                </div>
                            </div>

                            <div class="custom--card">
                                <div class="table-responsive--md">
                                    <table class="table custom--table">
                                        <thead>
                                            <tr>
                                                <th><?php echo app('translator')->get('Account Number'); ?></th>
                                                <th><?php echo app('translator')->get('Account Name'); ?></th>
                                                <th><?php echo app('translator')->get('Short Name'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $ownBeneficiaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td data-label="<?php echo app('translator')->get('Account Number'); ?>">
                                                        <?php echo e($beneficiary->account_number); ?>

                                                    </td>
                                                    <td data-label="<?php echo app('translator')->get('Account Number'); ?>">
                                                        <?php echo e($beneficiary->account_name); ?>

                                                    </td>
                                                    <td data-label="<?php echo app('translator')->get('Short Name'); ?>">
                                                        <?php echo e($beneficiary->short_name); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr><td colspan="100%" class="text-center"><?php echo app('translator')->get($emptyMessage); ?></td></tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>

                        
                        <div class="tab-pane fade" id="other-bank" role="tabpanel">

                              <div class="my-3 d-flex justify-content-end">
                                <button type="button" class="btn btn-sm btn--base add-other-btn"> <i class="fas fa-plus-circle"></i> <?php echo app('translator')->get('Add Beneficiary'); ?></button>
                              </div>


                            <div class="card border mb-3 d-none" id="addOtherForm">
                                <div class="card-body p-4">
                                    <form action="<?php echo e(route('user.transfer.beneficiary.other.add')); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>

                                        <div class="d-flex justify-content-between align-items-center">
                                            <h4><?php echo app('translator')->get('Add Beneficiary to Other Banks'); ?></h4>
                                            <button type="button" class="btn btn-sm btn--danger close-other-form"><i class="fas fa-times-circle"></i></button>
                                        </div>

                                        <div class="form-group">
                                            <label><?php echo app('translator')->get('Select Bank'); ?></label>
                                            <select class="form--control" name="bank">
                                              <option disabled selected value=""><?php echo app('translator')->get('Select One'); ?></option>
                                              <?php $__currentLoopData = $otherBanks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option data-fields='<?php echo json_encode($bank->user_data, 15, 512) ?>' value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label><?php echo app('translator')->get('Account Name'); ?> <span class="text--danger">*</span></label>
                                            <input type="text" name="account_name" class="form--control">
                                        </div>

                                        <div class="form-group">
                                            <label><?php echo app('translator')->get('Account Number'); ?> <span class="text--danger">*</span></label>
                                            <input type="text" name="account_number" class="form--control">
                                        </div>

                                        <div class="form-group">
                                            <label><?php echo app('translator')->get('Short Name'); ?> <span class="text--danger">*</span></label>
                                            <input type="text" name="short_name" class="form--control">
                                        </div>


                                        <div id="user-fields">

                                        </div>

                                        <div class="form-group">
                                            <button type="submit" class="btn w-100 btn--base"><?php echo app('translator')->get('Submit'); ?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <div class="custom--card">
                                <div class="table-responsive--md">
                                    <table class="table custom--table">
                                        <thead>
                                            <tr>
                                                <th><?php echo app('translator')->get('Bank'); ?></th>
                                                <th><?php echo app('translator')->get('Account No.'); ?></th>
                                                <th><?php echo app('translator')->get('Account Name'); ?></th>
                                                <th><?php echo app('translator')->get('Short Name'); ?></th>
                                                <th><?php echo app('translator')->get('Details'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $otherBeneficiaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td data-label="<?php echo app('translator')->get('Bank'); ?>">
                                                    <?php echo e($beneficiary->bank->name); ?>

                                                </td>

                                                <td data-label="<?php echo app('translator')->get('Account No.'); ?>">
                                                    <?php echo e($beneficiary->account_number); ?>

                                                </td>
                                                <td data-label="<?php echo app('translator')->get('Account Name.'); ?>">
                                                    <?php echo e($beneficiary->account_name); ?>

                                                </td>

                                                <td data-label="<?php echo app('translator')->get('Short Name'); ?>">
                                                    <?php echo e($beneficiary->short_name); ?>

                                                </td>
                                                <td data-label="<?php echo app('translator')->get('Details'); ?>">
                                                    <button class="btn btn-sm btn--base seeDetails"
                                                        data-bank_name="<?php echo e($beneficiary->bank->name); ?>"
                                                        data-short_name="<?php echo e($beneficiary->short_name); ?>"
                                                        data-details='<?php echo json_encode($beneficiary->details, 15, 512) ?>'
                                                    >
                                                        <i class="la la-desktop"></i>
                                                    </button>
                                                </td>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr><td colspan="100%" class="text-center"><?php echo app('translator')->get($emptyMessage); ?></td></tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>
    <!-- Modal -->
    <div class="modal fade" id="detailsModal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Benficiary Details'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <ul class="list-group list-group-flush">
                    </ul>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('bottom-menu'); ?>
    <?php if($general->modules->own_bank || $general->modules->other_bank): ?>
        <li><a href="<?php echo e(route('user.transfer.beneficiary.manage')); ?>" class="active"><?php echo app('translator')->get('Beneficiary Management'); ?></a></li>
        <?php if($general->modules->own_bank): ?>
            <li><a href="<?php echo e(route('user.transfer.own')); ?>"><?php echo app('translator')->get('Transfer Within'); ?> <?php echo app('translator')->get($general->sitename); ?></a></li>
        <?php endif; ?>
        <?php if($general->modules->other_bank): ?>
            <li><a href="<?php echo e(route('user.transfer.other')); ?>"><?php echo app('translator')->get('Transfer To Other Bank'); ?></a></li>
        <?php endif; ?>

        <li>
            <a href="<?php echo e(route('user.transfer.history')); ?>"><?php echo app('translator')->get('Transfer History'); ?></a>
        </li>
    <?php endif; ?>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        (function($){
            const addForm       = $('#addForm');
            const addOtherForm  = $('#addOtherForm');

            $('.add-btn').on('click', function(){
                addForm.removeClass('d-none').hide().fadeIn(500);
            });

            $('.add-other-btn').on('click', function(){
                addOtherForm.removeClass('d-none').hide().fadeIn(500);
            });

            $('.close-form-btn').on('click', function(){
                addForm.fadeOut(500);
            });

            $('.close-other-form').on('click', function(){
                addOtherForm.fadeOut(500);
            });


            addForm.find('input[name=account_number]').on('focusout', function(){
                let $this = $(this);
                let route   = `<?php echo e(route('user.accountnumber.check', '')); ?>/${$this.val()}`
                $.get(route, function(response) {
                    if(response.error){
                        $this.parent('.form-group').find('.error-message').text(response.message);

                        addForm.find('input:not(input[name=account_number])').attr('disabled', 'disabled')
                        addForm.find('input[name=account_name]').val('')
                    }else{
                        addForm.find('input[name=account_name]').val(response.data.name).attr('readonly', 'readonly')
                        addForm.find('input').removeAttr('disabled')

                        $this.parent('.form-group').find('.error-message').text('');
                    }

                });
            });

            addOtherForm.find('select[name=bank]').on('change', function(){
                let fields = $(this).find('option:selected').data('fields');
                let output = ``;
                fields.forEach(element => {
                    if(element.type == 'text') {
                        output +=
                        `
                            <div class="form-group">
                                <label><?php echo app('translator')->get('${element.field_name}'); ?> <span class="text--danger">*</span></label>
                                <input type="text" name="${snakeCase(element.field_name)}" class="form--control" ${element.validation}>
                            </div>
                        `;
                    }else if(element.type == 'textarea'){
                        output +=
                        `
                            <div class="form-group">
                                <label><?php echo app('translator')->get('${element.field_name}'); ?> <span class="text--danger">*</span></label>
                                <textarea type="text" name="${snakeCase(element.field_name)}" class="form--control" ${element.validation}></textarea>
                            </div>
                        `;
                    }else if(element.type == 'file'){
                        output +=
                        `
                            <div class="form-group">
                                <label><?php echo app('translator')->get('${element.field_name}'); ?> <span class="text--danger">*</span></label>
                                <input type="file" name="${snakeCase(element.field_name)}" class="form--control" accept=".jpg,.jpeg,.png" ${element.validation}>
                            </div>
                        `
                    }
                });
                $('#user-fields').html(output).hide().fadeIn(500);
            });

            $('.nav-link').on('click', function(){
                let name = $(this).data('name');
                localStorage.setItem('tabType', name);
            });

            function selectTab(){
                let tab = localStorage.getItem('tabType');
                if(tab){
                    $('.nav-link').removeClass('active')
                    $('.tab-pane').removeClass('active')
                    if(tab == 'own'){
                        $('.nav-link[data-name=own]').addClass('active');
                        $('#own-bank').addClass('active show')
                    }else if(tab == 'other'){
                        $('.nav-link[data-name=other]').addClass('active')
                        $('#other-bank').addClass('active show')
                    }
                }
            }

            selectTab();

            $('.seeDetails').on('click', function(){
                let modal       = $('#detailsModal');
                let details     = $(this).data('details');
                let imagePath   = "<?php echo e(asset(imagePath()['transfer']['beneficiary_data']['path'])); ?>/";
                let html    = `
                    <li class="list-group-item d-flex flex-wrap justify-content-between">
                        <span><?php echo app('translator')->get('Bank Name'); ?></span>
                        ${$(this).data('bank_name')}
                    </li>
                    <li class="list-group-item d-flex flex-wrap justify-content-between">
                        <span><?php echo app('translator')->get('Short Name'); ?></span>
                        ${$(this).data('short_name')}
                    </li>
                `;
                $.each(details, function (i, value) {
                    if(value.type == 'file'){
                        html +=
                        `
                            <li class="list-group-item d-flex flex-wrap justify-content-between">
                                <span><?php echo app('translator')->get('${titleCase(i)}'); ?></span>
                                <img class="w-75" src="${imagePath}${value.value}">
                            </li>
                        `;
                    }else {
                        html +=
                        `
                            <li class="list-group-item d-flex flex-wrap justify-content-between">
                                <span><?php echo app('translator')->get('${titleCase(i)}'); ?></span>
                                ${value.value}
                            </li>
                        `
                    }
                });
                modal.find('.modal-body .list-group').html(html);
                modal.modal('show');
            });
        })(jQuery)
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/transfers/beneficiary/manage.blade.php ENDPATH**/ ?>