<?php
	$captcha = loadCustomCaptcha($height = 46, $width = '100%');
?>
<?php if($captcha): ?>
    <div class="form-group col-lg-12">
        <label for="recaptcha-code"><?php echo app('translator')->get('Captcha'); ?></label>
        <?php echo $captcha ?>
        <input type="text" name="captcha" id="recaptcha-code" placeholder="<?php echo app('translator')->get('Enter Captcha'); ?>" class="form--control mt-3" autocomplete="off">
    </div>
<?php endif; ?>

<?php $__env->startPush('style'); ?>
<style>
    .capcha div{
        width: 100% !important;
    }
</style>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/partials/custom_captcha.blade.php ENDPATH**/ ?>