<header class="header">
    <div class="header__bottom">
        <div class="container">
        <nav class="navbar navbar-expand-lg p-0 align-items-center justify-content-between">
            <a class="site-logo site-title" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="logo"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="menu-toggle"></span>
            </button>
            <div class="collapse navbar-collapse mt-xl-0 mt-3" id="navbarSupportedContent">
                <ul class="navbar-nav main-menu m-auto">
                    <li>
                        <a class="<?php echo e(menuActive('user.home')); ?>" href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a>
                    </li>

                    <?php if($general->modules->deposit): ?>
                        <li>
                            <a class="<?php echo e(menuActive('user.deposit*')); ?>" href="<?php echo e(route('user.deposit.history')); ?>"><?php echo app('translator')->get('Deposit'); ?></a>
                        </li>
                    <?php endif; ?>

                    <?php if($general->modules->withdraw): ?>
                        <li>
                            <a class="<?php echo e(menuActive('user.withdraw*')); ?>" href="<?php echo e(route('user.withdraw.history')); ?>"><?php echo app('translator')->get('Withdraw'); ?></a>
                        </li>
                    <?php endif; ?>

                    <?php if($general->modules->fdr): ?>
                        <li>
                            <a class="<?php echo e(menuActive('user.fdr*')); ?>" href="<?php echo e(route('user.fdr.plans')); ?>"><?php echo app('translator')->get('FDR'); ?></a>
                        </li>
                    <?php endif; ?>

                    <?php if($general->modules->dps): ?>
                        <li>
                            <a class="<?php echo e(menuActive('user.dps*')); ?>" href="<?php echo e(route('user.dps.plans')); ?>"><?php echo app('translator')->get('DPS'); ?></a>
                        </li>
                    <?php endif; ?>

                    <?php if($general->modules->loan): ?>
                        <li>
                            <a class="<?php echo e(menuActive('user.loan*')); ?>" href="<?php echo e(route('user.loan.plans')); ?>"><?php echo app('translator')->get('Loan'); ?></a>
                        </li>
                    <?php endif; ?>

                    <?php if($general->modules->own_bank || $general->modules->other_bank): ?>
                        <li>
                            <a class="<?php echo e(menuActive('user.transfer*')); ?>" href="<?php echo e(route('user.transfer.beneficiary.manage')); ?>"><?php echo app('translator')->get('Transfer'); ?></a>
                        </li>
                    <?php endif; ?>

                    <li>
                        <a class="<?php echo e(menuActive(['user.profile.setting', 'user.twofactor', 'user.change.password', 'user.transaction.history', 'ticket', 'ticket.open', 'ticket.view', 'user.referral.*'])); ?>" href="<?php echo e(route('user.profile.setting')); ?>"><?php echo app('translator')->get('More'); ?></a>
                    </li>
                </ul>
                <div class="nav-right">
                    <select class="language-select me-3 langSel">
                        <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->code); ?>" <?php if(session('lang') == $item->code): ?> selected <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <a href="<?php echo e(route('user.logout')); ?>" class="btn btn-sm py-2 custom--bg text-white"> <i class="fa fa-sign-out-alt" aria-hidden="true"></i> <?php echo app('translator')->get('Logout'); ?></a>
                </div>
            </div>
        </nav>
        </div>
    </div>
</header>


<?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/partials/auth_header.blade.php ENDPATH**/ ?>