<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH /home/trustspr/public_html/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>