<?php $__env->startSection('panel'); ?>
<div class="row">

    <div class="col-lg-12">
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive--md table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('FDR No. | Plan'); ?></th>
                                <th><?php echo app('translator')->get('User'); ?></th>
                                <th><?php echo app('translator')->get('Amount'); ?></th>
                                <th><?php echo app('translator')->get('Profit'); ?></th>
                                <th><?php echo app('translator')->get('Next Installment'); ?></th>
                                <th><?php echo app('translator')->get('Lock In Period'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fdr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('FDR No.'); ?>">
                                        <span class="font-weight-bold"><?php echo e(__($fdr->trx)); ?></span>
                                        <span class="d-block text--info"><?php echo e(__($fdr->plan->name)); ?></span>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('User'); ?>">
                                        <span class="font-weight-bold d-block"><?php echo e($fdr->user->fullname); ?></span>
                                        <span class="small">
                                        <a href="<?php echo e(route('admin.users.detail', $fdr->user_id)); ?>"><span>@</span><?php echo e($fdr->user->username); ?></a>
                                        </span>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                        <span><?php echo e($general->cur_sym.showAmount($fdr->amount)); ?></span>
                                        <span class="d-block text--info"><?php echo app('translator')->get('Profit'); ?> <?php echo e(getAmount($fdr->plan->interest_rate)); ?>% </span>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Profit'); ?>">
                                        <span><?php echo e($general->cur_sym.showAmount($fdr->interest)); ?></span>
                                        <span class="text--info d-block"><?php echo app('translator')->get('Per'); ?> <?php echo e($fdr->interest_interval); ?> <?php echo app('translator')->get('Days'); ?></span>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Next Installment'); ?>">
                                        <span>
                                            <?php echo e(showDateTime($fdr->next_return_date, 'd M, Y')); ?>

                                        </span>
                                        <span class="d-block text--info"><?php echo e(diffForHumans($fdr->next_return_date, 'd M, Y')); ?></span>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Lock In Period'); ?>">
                                        <span>
                                            <?php echo e(showDateTime($fdr->locked_date, 'd M, Y')); ?>

                                        </span>
                                        <span class="d-block text--info"><?php echo e(diffForHumans($fdr->locked_date, 'd M, Y')); ?></span>

                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                        <?php if($fdr->status == 1): ?>
                                            <span class="badge badge--success"><?php echo app('translator')->get('Running'); ?></span>
                                        <?php elseif($fdr->status == 2): ?>
                                            <span class="badge badge--danger"><?php echo app('translator')->get('Completed'); ?></span>
                                        <?php endif; ?>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                        <a href="<?php echo e(route('admin.fdr.isntallments', $fdr->id)); ?>" class="icon-btn" data-toggle="tooltip" data-title="Installment History">
                                            <i class="las la-desktop"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table><!-- table end -->
                </div>
            </div>
            <?php if($data->hasPages()): ?>
                <div class="card-footer py-4">
                <?php echo e(paginateLinks($data)); ?>

                </div>
            <?php endif; ?>
        </div><!-- card end -->
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('breadcrumb-plugins'); ?>
    <form action="" method="GET" class="form-inline float-sm-right bg--white">
        <div class="input-group has_append">
            <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('FDR No.'); ?>" value="<?php echo e(request()->search ?? ''); ?>">
            <div class="input-group-append">
                <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
            </div>
        </div>
    </form>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/admin/fdr/index.blade.php ENDPATH**/ ?>