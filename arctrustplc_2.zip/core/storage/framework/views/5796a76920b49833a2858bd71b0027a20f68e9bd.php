<?php $__env->startSection('content'); ?>

<!-- dashboard section start -->

<div class="container">
    <div class="plan-area mb-none-30">
        <div class="row justify-content-center gy-4">
            <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 col-md-6">
                    <div class="plan-card rounded-3 wow fadeInUp">
                        <div class="plan-card__header">
                            <div class="wave-shape">
                                <img src="<?php echo e(asset($activeTemplateTrue. 'images/elements/wave.png')); ?>" alt="img">
                            </div>
                            <h4 class="plan-name"><?php echo e(__($plan->name)); ?></h4>
                            <div class="plan-price">
                                <?php echo e(getAmount($plan->per_installment)); ?>% <sub>/<?php echo e($plan->installment_interval); ?> <?php echo app('translator')->get('Days'); ?></sub>
                            </div>
                        </div>
                        <div class="plan-card__body text-center">
                            <ul class="plan-feature-list">
                                <li class="d-flex flex-wrap justify-content-between">
                                    <span><?php echo app('translator')->get('Take Minimum'); ?></span>
                                    <?php echo e($general->cur_sym); ?><?php echo e(showAmount($plan->minimum_amount)); ?>

                                </li>

                                <li class="d-flex flex-wrap justify-content-between">
                                    <span><?php echo app('translator')->get('Take Maximum'); ?></span>
                                    <?php echo e($general->cur_sym); ?><?php echo e(showAmount($plan->maximum_amount)); ?>

                                </li>

                                <li class="d-flex flex-wrap justify-content-between">
                                    <span>
                                        <?php echo app('translator')->get('Per Installment'); ?>
                                    </span>
                                    <?php echo e(getAmount($plan->per_installment)); ?>%
                                </li>

                                <li class="d-flex flex-wrap justify-content-between">
                                    <span>
                                        <?php echo app('translator')->get('Installment Interval'); ?>

                                    </span>
                                    <?php echo e($plan->installment_interval); ?> <?php echo app('translator')->get('Days'); ?>
                                </li>

                                <li class="d-flex flex-wrap justify-content-between">
                                    <span>
                                        <?php echo app('translator')->get('Total Installment'); ?>
                                    </span>
                                    <?php echo e($plan->total_installment); ?>

                                </li>


                            </ul>
                        </div>
                        <div class="plan-card__footer text-center">
                            <button type="button" data-id="<?php echo e($plan->id); ?>" data-minimum="<?php echo e($general->cur_sym); ?><?php echo e(showAmount($plan->minimum_amount)); ?>" data-maximum="<?php echo e($general->cur_sym); ?><?php echo e(showAmount($plan->maximum_amount)); ?>" class="btn btn-md w-100 btn--base loanBtn"><?php echo app('translator')->get('Apply Now'); ?></button>
                        </div>
                    </div><!-- plan-card end -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php echo e($plans->links()); ?>


    </div><!-- row end -->
</div>
<!-- dashboard section end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>
    <div class="modal fade" id="loanModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <strong class="modal-title method-name" id="exampleModalLabel"><?php echo app('translator')->get('Apply for Loan'); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                    </a>
                </div>
                <form action="<?php echo e(route('user.loan.apply')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="id">
                        <div class="form-group">
                            <label for=""><?php echo app('translator')->get('Amount'); ?></label>
                            <input type="text" name="amount" class="form-control" placeholder="<?php echo app('translator')->get('Enter An Amount'); ?>">
                            <p><small class="text--danger min-limit mt-2"></small></p>
                            <p><small class="text-danger max-limit"></small></p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-md btn-danger text-white"
                            data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-md custom--bg text-white"><?php echo app('translator')->get('Confirm'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            $('.loanBtn').on('click', (e) => {
                var modal = $('#loanModal');
                var $this = $(e.currentTarget);
                modal.find('input[name=id]').val($this.data('id'));
                modal.find('.min-limit').text(`Minimum Amount ${$this.data('minimum')}`);
                modal.find('.max-limit').text(`Maximum Amount ${$this.data('maximum')}`);
                modal.modal('show');
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>



<?php $__env->startPush('bottom-menu'); ?>
    <li>
        <a href="<?php echo e(route('user.loan.plans')); ?>" class="active"><?php echo app('translator')->get('Loan Plans'); ?></a>
    </li>
    <li>
        <a href="<?php echo e(route('user.loan.list')); ?>"><?php echo app('translator')->get('My Loan List'); ?></a>
    </li>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/loan/plans.blade.php ENDPATH**/ ?>