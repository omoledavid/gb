<?php $__env->startSection('content'); ?>

<!-- dashboard section start -->
    <div class="container">
        <div class="row align-items-center mb-3">
            <div class="col-lg-6">
                <h6><?php echo app('translator')->get('My Deposit History'); ?></h6>
            </div>
            <div class="col-lg-6 text-lg-end">
                <button type="button" data-bs-toggle="modal" data-bs-target="#depositModal" class="btn btn-sm btn--base"><i class="las la-plus-circle"></i> <?php echo app('translator')->get('Deposit Now'); ?></button>
            </div>
        </div>
        <div class="custom--card">
            <div class="card-body p-0">
            <div class="table-responsive--md">
                <table class="table custom--table">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('TRX | Method'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Amount | Charge'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Rate'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Payable Amount'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Details'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($logs) > 0): ?>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Date'); ?>">
                                        <?php echo e(showDateTime($data->created_at, 'd M, Y h:i A')); ?>

                                        <small class="d-block text--base">
                                            <?php echo e(diffForHumans($data->created_at)); ?>

                                        </small>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('TRX | Method'); ?>">
                                        <span class="d-block">
                                            <?php echo e($data->trx); ?>

                                        </span>
                                        <small class="d-block text--base">
                                            <?php echo e(__(@$data->gateway->name)); ?>

                                        </small>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Amount | Charge'); ?>">
                                        <strong><?php echo e(showAmount($data->amount)); ?> <?php echo e(__($general->cur_text)); ?></strong>
                                        <small class="d-block text--danger"><?php echo e(showAmount($data->charge)); ?> <?php echo e(__($general->cur_text)); ?></small>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Rate'); ?>">
                                        <span><?php echo e(showAmount($data->rate)); ?> <?php echo e(__($data->method_currency)); ?></span>
                                        <small class="d-block text--base">
                                            <?php echo app('translator')->get('Per'); ?> <?php echo app('translator')->get($general->cur_text); ?>
                                        </small>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Payable Amount'); ?>">
                                        <strong>
                                            <?php echo e(showAmount($data->final_amo)); ?> <?php echo e(__($data->method_currency)); ?>

                                        </strong>

                                        <small class="d-block text--base">
                                            <?php echo e(showAmount($data->amount + $data->charge)); ?> <?php echo e(__($general->cur_text)); ?>

                                        </small>
                                    </td>


                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                        <?php if($data->status == 1): ?>
                                            <span class="badge badge--success"><?php echo app('translator')->get('Complete'); ?></span>
                                        <?php elseif($data->status == 2): ?>
                                            <span class="badge badge--warning"><?php echo app('translator')->get('Pending'); ?></span>
                                        <?php elseif($data->status == 3): ?>
                                            <span class="badge badge--danger"><?php echo app('translator')->get('Cancel'); ?></span>
                                        <?php endif; ?>

                                        <?php if($data->admin_feedback != null): ?>
                                            <button class="btn-info btn-rounded badge detailBtn" data-admin_feedback="<?php echo e($data->admin_feedback); ?>"><i class="fa fa-info"></i></button>
                                        <?php endif; ?>
                                    </td>

                                    <?php
                                        $details = ($data->detail != null) ? json_encode($data->detail) : null;
                                    ?>

                                    <td data-label="<?php echo app('translator')->get('Details'); ?>">
                                        <a href="javascript:void(0)" class="btn btn-primary btn-sm detailModal approveBtn"
                                        data-info="<?php echo e($details); ?>"
                                        data-id="<?php echo e($data->id); ?>"
                                        data-amount="<?php echo e(showAmount($data->amount)); ?> <?php echo e(__($general->cur_text)); ?>"
                                        data-charge="<?php echo e(showAmount($data->charge)); ?> <?php echo e(__($general->cur_text)); ?>"
                                        data-after_charge="<?php echo e(showAmount($data->amount + $data->charge)); ?> <?php echo e(__($general->cur_text)); ?>"
                                        data-rate="<?php echo e(showAmount($data->rate)); ?> <?php echo e(__($data->method_currency)); ?>"
                                        data-payable="<?php echo e(showAmount($data->final_amo)); ?> <?php echo e(__($data->method_currency)); ?>">
                                            <i class="fa fa-desktop"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="100%"> <?php echo app('translator')->get('No deposit yet'); ?>!</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php echo e($logs->links()); ?>

            </div>
            </div>
        </div>
    </div>

  <!-- dashboard section end -->

<?php $__env->stopSection(); ?>


<?php $__env->startPush('modal'); ?>
    
    <div id="approveModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Details'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <ul class="list-group list-group-flush border">
                        <li class="border-bottom p-2 d-flex flex-wrap justify-content-between"><?php echo app('translator')->get('Amount'); ?> : <span class="withdraw-amount value"></span></li>
                        <li class="border-bottom p-2 d-flex flex-wrap justify-content-between"><?php echo app('translator')->get('Charge'); ?> : <span class="withdraw-charge "></span></li>
                        <li class="border-bottom p-2 d-flex flex-wrap justify-content-between"><?php echo app('translator')->get('After Charge'); ?> : <span class="withdraw-after_charge"></span></li>
                        <li class="border-bottom p-2 d-flex flex-wrap justify-content-between"><?php echo app('translator')->get('Conversion Rate'); ?> : <span class="withdraw-rate"></span></li>
                        <li class="d-flex p-2 flex-wrap justify-content-between"><?php echo app('translator')->get('Payable Amount'); ?> : <span class="withdraw-payable"></span></li>
                    </ul>
                    <ul class="list-group withdraw-detail mt-1">
                    </ul>
                </div>

            </div>
        </div>
    </div>

    
    <div id="detailModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Details'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="withdraw-detail"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger btn-md" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>


<!-- Deposit Modal -->
    <div id="depositModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Deposit Money'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('user.deposit.insert')); ?>" method="post">
                <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="currency">
                        <div class="form-group">
                            <label for="paymentGateway" class="fw-bold"><?php echo app('translator')->get('Payment Method'); ?></label>
                            <select class="form--control" name="method_code" id="paymentGateway">
                                <option disabled selected value=""><?php echo app('translator')->get('Select One'); ?></option>
                                <?php $__currentLoopData = $gatewayCurrency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        data-currency="<?php echo e($gateway->currency); ?>"
                                        data-min_amount="<?php echo e(getAmount($gateway->min_amount)); ?>"
                                        data-max_amount="<?php echo e(getAmount($gateway->max_amount)); ?>"
                                        data-fix_charge="<?php echo e(getAmount($gateway->fixed_charge)); ?>"
                                        data-percent_charge="<?php echo e(getAmount($gateway->percent_charge)); ?>"
                                        value="<?php echo e($gateway->method_code); ?>">
                                        <?php echo app('translator')->get($gateway->name); ?>
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <div class="mt-3">
                                <p><small class="text--danger depositLimit mt-2"></small></p>
                                <p><small class="text-danger depositCharge"></small></p>
                            </div>

                        </div>
                        <div class="form-group">
                            <label class="fw-bold" for="amount"><?php echo app('translator')->get('Amount'); ?></label>
                            <div class="input-group">
                                <input id="amount" type="text" class="form--control" name="amount" placeholder="0.00" value="<?php echo e(old('amount')); ?>" required>
                                <span class="input-group-text bg--base text-white border--base"><?php echo e(__($general->cur_text)); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger btn-md" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--base btn-md"><?php echo app('translator')->get('Confirm'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            $('.approveBtn').on('click', function() {
                var modal = $('#approveModal');
                modal.find('.withdraw-amount').text($(this).data('amount'));
                modal.find('.withdraw-charge').text($(this).data('charge'));
                modal.find('.withdraw-after_charge').text($(this).data('after_charge'));
                modal.find('.withdraw-rate').text($(this).data('rate'));
                modal.find('.withdraw-payable').text($(this).data('payable'));
                var list = [];
                var details =  Object.entries($(this).data('info'));

                var ImgPath = "<?php echo e(asset(imagePath()['verify']['deposit']['path'])); ?>/";
                var singleInfo = '';
                for (var i = 0; i < details.length; i++) {
                    if (details[i][1].type == 'file') {
                        singleInfo += `<li class="list-group-item">
                                            <span class="font-weight-bold "> ${details[i][0].replaceAll('_', " ")} </span> : <img src="${ImgPath}/${details[i][1].field_name}" alt="<?php echo app('translator')->get('Image'); ?>" class="w-100">
                                        </li>`;
                    }else{
                        singleInfo += `<li class="list-group-item">
                                            <span class="font-weight-bold "> ${details[i][0].replaceAll('_', " ")} </span> : <span class="font-weight-bold ml-3">${details[i][1].field_name}</span>
                                        </li>`;
                    }
                }

                if (singleInfo)
                {
                    modal.find('.withdraw-detail').html(`<br><strong class="my-3"><?php echo app('translator')->get('Payment Information'); ?></strong>  ${singleInfo}`);
                }else{
                    modal.find('.withdraw-detail').html(`${singleInfo}`);
                }
                modal.modal('show');
            });

            $('.detailBtn').on('click', function() {
                var modal = $('#detailModal');
                var feedback = $(this).data('admin_feedback');
                modal.find('.withdraw-detail').html(`<p> ${feedback} </p>`);
                modal.modal('show');
            });

            $('#paymentGateway').on('change', function(){
                let option = $(this).find('option:selected');
                $('input[name=currency]').val(option.data('currency'));
                var minAmount       = option.data('min_amount');
                var maxAmount       = option.data('max_amount');
                var baseSymbol      = "<?php echo e($general->cur_text); ?>";
                var fixCharge       = option.data('fix_charge');
                var percentCharge   = option.data('percent_charge');
                var depositLimit    = `<?php echo app('translator')->get('Deposit Limit'); ?>: ${minAmount} - ${maxAmount}  ${baseSymbol}`;
                $('.depositLimit').text(depositLimit);
                var depositCharge = `<?php echo app('translator')->get('Charge'); ?>: ${fixCharge} ${baseSymbol}  ${(0 < percentCharge) ? ' + ' +percentCharge + ' % ' : ''}`;
                $('.depositCharge').text(depositCharge);
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/deposit/log.blade.php ENDPATH**/ ?>