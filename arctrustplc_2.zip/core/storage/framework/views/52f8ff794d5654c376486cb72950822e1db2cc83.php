<?php $__env->startSection('panel'); ?>
    <div class="card">
        <form action="<?php echo e(route('admin.bank.edit', $bank->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name"><?php echo app('translator')->get('Bank Name'); ?> <span class="text--danger">*</span></label>
                            <div class="input-group">
                                <input type="text" name="name" id="name" class="form-control border-radius-5" placeholder="Bank Name" value="<?php echo e($bank->name); ?>" required />
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="processing_time"><?php echo app('translator')->get('Processing Time'); ?>
                                <span class="text--danger">*</span>
                            </label>
                            <div class="form-group">
                                <div class="input-group">
                                    <input type="text" name="processing_time" id="processing_time" class="form-control border-radius-5" placeholder="Processing Time" value="<?php echo e($bank->processing_time); ?>" required/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-lg-12">
                        <div class="card border--dark">
                            <h5 class="card-header bg--dark"><?php echo app('translator')->get('Transfer Limit'); ?></h5>
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="minimum_amount">
                                            <?php echo app('translator')->get('Minimum Amount'); ?> <span class="text--danger">*</span>
                                        </label>
                                        <div class="input-group">
                                            <input type="text" class="form-control numeric-validation"
                                                id="minimum_amount" placeholder="0" name="minimum_amount"
                                                value="<?php echo e(getAmount($bank->minimum_limit)); ?>" required />
                                            <div class="input-group-append">
                                                <div class="input-group-text"> <?php echo e(__($general->cur_text)); ?> </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="maximum_amount">
                                            <?php echo app('translator')->get('Maximum Amount'); ?><span class="text--danger">*</span>
                                        </label>
                                        <div class="input-group">
                                            <input type="text" class="form-control numeric-validation" id="maximum_amount"
                                                placeholder="0" name="maximum_amount" value="<?php echo e(getAmount($bank->maximum_limit)); ?>" required />
                                            <div class="input-group-append">
                                                <div class="input-group-text"> <?php echo e(__($general->cur_text)); ?> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <h4 class="text-muted my-3 border-bottom pb-2"><?php echo app('translator')->get('Daily Limit'); ?></h4>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="daily_maximum_amount">
                                            <?php echo app('translator')->get('Maximum Transaction Amount'); ?><span class="text--danger">*</span>
                                        </label>
                                        <div class="input-group">
                                            <input type="text" class="form-control numeric-validation" id="daily_maximum_amount"
                                                placeholder="0" name="daily_maximum_amount" value="<?php echo e(getAmount($bank->daily_maximum_limit)); ?>" required />
                                            <div class="input-group-append">
                                                <div class="input-group-text"> <?php echo e(__($general->cur_text)); ?> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="daily_transaction_count">
                                            <?php echo app('translator')->get('Maximum Transaction Count'); ?><span class="text--danger">*</span>
                                        </label>
                                        <input type="text" class="form-control integer-validation" id="daily_transaction_count" placeholder="0" name="daily_transaction_count" value="<?php echo e(getAmount($bank->daily_total_transaction)); ?>" required />
                                    </div>
                                </div>


                                <h4 class="text-muted my-3 border-bottom pb-2"><?php echo app('translator')->get('Monthly Limit'); ?></h4>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="monthly_maximum_amount">
                                            <?php echo app('translator')->get('Maximum Transaction Amount'); ?><span class="text--danger">*</span>
                                        </label>
                                        <div class="input-group">
                                            <input type="text" class="form-control numeric-validation" id="monthly_maximum_amount"
                                                placeholder="0" name="monthly_maximum_amount" value="<?php echo e(getAmount($bank->monthly_maximum_limit)); ?>" required />
                                            <div class="input-group-append">
                                                <div class="input-group-text"> <?php echo e(__($general->cur_text)); ?> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="monthly_transaction_count">
                                            <?php echo app('translator')->get('Maximum Transaction Count'); ?><span class="text--danger">*</span>
                                        </label>
                                        <input type="text" class="form-control integer-validation" id="monthly_transaction_count" placeholder="0" name="monthly_transaction_count" value="<?php echo e(getAmount($bank->monthly_total_transaction)); ?>" required />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-12 mt-3">
                        <div class="card border--dark">
                            <h5 class="card-header bg--dark"><?php echo app('translator')->get('Transfer Charge'); ?></h5>
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="fixed_charge">
                                            <?php echo app('translator')->get('Fixed Charge'); ?>
                                            <span class="text--danger">*</span>
                                        </label>
                                        <div class="input-group">
                                            <input type="text" class="form-control numeric-validation"
                                                placeholder="0" name="fixed_charge" id="fixed_charge"
                                                value="<?php echo e(getAmount($bank->fixed_charge)); ?>" required />
                                            <div class="input-group-append">
                                                <div class="input-group-text"> <?php echo e(__($general->cur_text)); ?> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="percent_charge">
                                            <?php echo app('translator')->get('Percent Charge'); ?>
                                            <span class="text--danger">*</span>
                                        </label>
                                        <div class="input-group">
                                            <input type="text" class="form-control numeric-validation"
                                                placeholder="0" name="percent_charge" id="percent_charge"
                                                value="<?php echo e(getAmount($bank->percent_charge)); ?>" required />
                                            <div class="input-group-append">
                                                <div class="input-group-text">%</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12 mt-3">
                        <div class="card border--dark">
                            <h5 class="card-header bg--dark p-2"><?php echo app('translator')->get('Instruction'); ?> </h5>
                            <div class="card-body">
                                <textarea rows="5" class="form-control nicEdit" name="instruction"><?php echo $bank->instruction ?></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12 mt-4">
                        <div class="card border--dark">
                            <h5 class="card-header bg--dark p-2"><?php echo app('translator')->get('User\'s Required Information'); ?></h5>
                            <div class="card-body">

                                <div class="d-flex flex-wrap  mb-3">
                                    <div class="w-50">
                                        <input name="account_name" class="form-control rounded-0 bg-white text--black" type="text" value="Account Name" required placeholder="<?php echo app('translator')->get('Field Name'); ?>" readonly>
                                    </div>

                                    <div class="w-25">
                                        <select  class="form-control rounded-0">
                                            <option value="text"> <?php echo app('translator')->get('Input'); ?> </option>
                                        </select>
                                    </div>
                                    <div class="w-25">
                                        <select class="form-control rounded-0">
                                            <option value="required"> <?php echo app('translator')->get('Required'); ?> </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="d-flex flex-wrap  mb-3">
                                    <div class="w-50">
                                        <input name="account_name" class="form-control rounded-0 bg-white text--black" type="text" value="Account Number" required placeholder="<?php echo app('translator')->get('Field Name'); ?>" readonly>
                                    </div>

                                    <div class="w-25">
                                        <select  class="form-control rounded-0">
                                            <option value="text"> <?php echo app('translator')->get('Input'); ?> </option>
                                        </select>
                                    </div>
                                    <div class="w-25">
                                        <select class="form-control rounded-0">
                                            <option value="required"> <?php echo app('translator')->get('Required'); ?> </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="addedField">
                                    <?php if($fieldsCount): ?>
                                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="user-data border mb-3">
                                                <button class="btn--danger removeBtn mb-1" type="button">
                                                    <i class="fa fa-times"></i>
                                                </button>
                                                <div class="d-flex flex-wrap">
                                                    <div class="w-50">
                                                        <input name="input_form[<?php echo e($loop->index); ?>][field_name]" class="form-control rounded-0" type="text" value="<?php echo e($v->field_name); ?>" required placeholder="<?php echo app('translator')->get('Field Name'); ?>">
                                                    </div>
                                                    <div class="w-25">
                                                        <select name="input_form[<?php echo e($loop->index); ?>][type]" class="form-control rounded-0">
                                                            <option value="text" <?php if($v->type == 'text'): ?> selected <?php endif; ?>>
                                                                <?php echo app('translator')->get('Input Text'); ?>
                                                            </option>
                                                            <option value="textarea" <?php if($v->type == 'textarea'): ?> selected <?php endif; ?>>
                                                                <?php echo app('translator')->get('Textarea'); ?>
                                                            </option>
                                                            <option value="file" <?php if($v->type == 'file'): ?> selected <?php endif; ?>>
                                                                <?php echo app('translator')->get('File upload'); ?>
                                                            </option>
                                                        </select>
                                                    </div>
                                                    <div class="w-25">
                                                        <select name="input_form[<?php echo e($loop->index); ?>][validation]" class="form-control rounded-0">
                                                            <option value="required" <?php if($v->validation == 'required'): ?> selected <?php endif; ?>> <?php echo app('translator')->get('Required'); ?> </option>
                                                            <option value="nullable" <?php if($v->validation == 'nullable'): ?> selected <?php endif; ?>>  <?php echo app('translator')->get('Optional'); ?> </option>
                                                        </select>
                                                    </div>

                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <button type="button" class="btn btn-sm btn--success addUserData">
                                    <i class="la la-fw la-plus"></i><?php if($fieldsCount): ?> <?php echo app('translator')->get('Add More'); ?> <?php else: ?> <?php echo app('translator')->get('Add Fields'); ?> <?php endif; ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn--primary btn-block"><?php echo app('translator')->get('Save Changes'); ?></button>
            </div>
        </form>
    </div><!-- card end -->
<?php $__env->stopSection(); ?>


<?php $__env->startPush('breadcrumb-plugins'); ?>
<a href="<?php echo e(route('admin.bank.index')); ?>" class="btn btn-sm btn--primary box--shadow1 text--small">
    <i class="la la-fw la-backward"></i> <?php echo app('translator')->get('Go Back'); ?>
</a>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
<style>
    .user-data {
        position: relative !important;
        border-radius: 5px;
    }

    .removeBtn {
        position: absolute;
        left: -5px;
        top: -5px;
        width: 20px;
        height: 20px;
        font-size: 10px;
        border-radius: 50%;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script>
    (function ($) {
        "use strict";
        let addCount = <?php echo e($fieldsCount); ?>;

        $('.addUserData').on('click', function () {
            var html = `
                    <div class="user-data border mb-3">
                        <button class="btn--danger removeBtn mb-1" type="button">
                            <i class="fa fa-times"></i>
                        </button>

                        <div class="d-flex flex-wrap">
                            <div class="w-50">
                                <input name="input_form[${addCount}][field_name]" class="form-control rounded-0" type="text" value="" required placeholder="<?php echo app('translator')->get('Field Name'); ?>">
                            </div>

                            <div class="w-25">
                                <select name="input_form[${addCount}][type]" class="form-control rounded-0">
                                    <option value="text"> <?php echo app('translator')->get('Input'); ?> </option>
                                    <option value="textarea" > <?php echo app('translator')->get('Textarea'); ?> </option>
                                    <option value="file"> <?php echo app('translator')->get('File upload'); ?> </option>
                                </select>
                            </div>


                            <div class="w-25">
                                <select name="input_form[${addCount}][validation]"
                                        class="form-control rounded-0">
                                    <option value="required"> <?php echo app('translator')->get('Required'); ?> </option>
                                    <option value="nullable">  <?php echo app('translator')->get('Optional'); ?> </option>
                                </select>
                            </div>
                        </div>
                    </div>`;

            $('.addedField').append(html);

            addCount++;

            changeButtonText();
        });

        function changeButtonText() {
            let count = $(document).find('.user-data').length
            if (count > 0) {
                $('.addUserData').html(`<i class="la la-fw la-plus"></i> <?php echo app('translator')->get('Add More'); ?>`)
            } else {
                $('.addUserData').html(`<i class="la la-fw la-plus"></i> <?php echo app('translator')->get('Add Fields'); ?>`)
            }
        }

        $(document).on('click', '.removeBtn', function () {
            $(this).closest('.user-data').remove();
            changeButtonText();
        });
    })(jQuery);

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/admin/other_banks/edit.blade.php ENDPATH**/ ?>