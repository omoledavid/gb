<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH C:\xampp\htdocs\work\2024\Jan\trustspring\core\resources\views/partials/plugins.blade.php ENDPATH**/ ?>