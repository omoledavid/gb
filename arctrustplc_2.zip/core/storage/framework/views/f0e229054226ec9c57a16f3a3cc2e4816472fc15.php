<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body p-0">
                    <div class="table-responsive--md table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('TRX | Bank'); ?></th>
                                    <th><?php echo app('translator')->get('Send By'); ?></th>
                                    <th><?php echo app('translator')->get('Received By'); ?></th>
                                    <th><?php echo app('translator')->get('Amount'); ?></th>
                                    <th><?php echo app('translator')->get('Final Amount'); ?></th>
                                    <th><?php echo app('translator')->get('Action'); ?></th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__empty_1 = true; $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td data-label="<?php echo app('translator')->get('TRX | Bank'); ?>">
                                            <span>
                                                <?php echo e($transfer->trx); ?>

                                            </span>

                                            <span class="d-block text--primary small">
                                                <?php if($transfer->bank_id==0): ?>
                                                    <?php echo e($general->sitename); ?>

                                                <?php else: ?>
                                                    <a href="<?php echo e(route('admin.bank.edit', $transfer->bank->id)); ?>"><?php echo app('translator')->get($transfer->bank->name); ?></a>
                                                <?php endif; ?>
                                            </span>

                                        </td>

                                        <td data-label="<?php echo app('translator')->get('Send By'); ?>">

                                            <span class="d-block">
                                                <?php echo e($transfer->user->account_number); ?>

                                            </span>

                                            <a href="<?php echo e(route('admin.users.detail', $transfer->user_id)); ?>">
                                                <span>@</span><?php echo e($transfer->user->username); ?>

                                            </a>
                                        </td>

                                        <td data-label="<?php echo app('translator')->get('Received By'); ?>">

                                            <span class="d-block">
                                                <?php echo e($transfer->beneficiary->account_number); ?>

                                            </span>

                                            <a href="<?php echo e(route('admin.users.detail', $transfer->user_id)); ?>">
                                                <span>@</span><?php echo e($transfer->beneficiary->account_number); ?>

                                            </a>
                                        </td>



                                        <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                            <span class="font-weight-bold">
                                                <?php echo e($general->cur_sym.showAmount($transfer->amount)); ?>

                                            </span>

                                            <span class="small d-block">
                                                <?php echo app('translator')->get('Charge'); ?>
                                                <span class="text--info font-weight-bold">
                                                    <?php echo e($general->cur_sym.showAmount($transfer->charge)); ?>

                                                </span>
                                            </span>
                                        </td>

                                        <td  data-label="<?php echo app('translator')->get('Final Amount'); ?>">
                                            <span class="font-weight-bold">
                                                <?php echo e($general->cur_sym.showAmount($transfer->final_amount)); ?>

                                            </span>
                                            <span class="text--info d-block">
                                                <?php echo app('translator')->get('With Charge'); ?>
                                            </span>
                                        </td>

                                        <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                            <a class="icon-btn" href="<?php echo e(route('admin.transfers.details', $transfer->id)); ?>">
                                                <i class="la la-desktop"></i>
                                            </a>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="100%" class="text-center"><?php echo app('translator')->get($emptyMessage); ?></td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
                <?php if($transfers->hasPages()): ?>
                    <div class="card-footer py-4">
                    <?php echo e(paginateLinks($transfers)); ?>

                    </div>
                <?php endif; ?>
            </div><!-- card end -->
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('breadcrumb-plugins'); ?>
    <form action="" method="GET" class="form-inline float-sm-right bg--white">
        <div class="input-group has_append">
            <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('TRX No.'); ?>" value="<?php echo e(request()->search ?? ''); ?>">
            <div class="input-group-append">
                <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
            </div>
        </div>
    </form>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/admin/transfers/index.blade.php ENDPATH**/ ?>