<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center mt-4">
            <div class="col-md-8">
                <div class="card border border--base">
                    <div class="card-header bg--base">
                        <h5 class="card-title m-0 p-2 text-white"><?php echo app('translator')->get('Change Your Password'); ?></h5>
                    </div>
                    <div class="card-body">
                        <form action="" method="post" class="register">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="currentPassword"><?php echo app('translator')->get('Current Password'); ?></label>
                                <div class="input-group">
                                    <input id="currentPassword" placeholder="Current Password" type="password" class="form--control" name="current_password" required autocomplete="current-password">
                                    <span class="input-group-text bg--base border--base text-white"><i class="las la-user-lock"></i></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="password"><?php echo app('translator')->get('Password'); ?></label>
                                <div class="input-group hover-input-popup">
                                    <input id="password" type="password" placeholder="New Password" class="form--control" name="password" required autocomplete="current-password">
                                    <span class="input-group-text bg--base border--base text-white"><i class="la la-key"></i></span>
                                    <?php if($general->secure_password): ?>
                                        <div class="input-popup">
                                            <p class="text-danger my-1 capital"><small><?php echo app('translator')->get('Minimum 1 capital letter is required'); ?></small></p>
                                            <p class="text-danger my-1 lower"><small><?php echo app('translator')->get('Minimum 1 small letter is required'); ?></small></p>
                                            <p class="text-danger my-1 number"><small><?php echo app('translator')->get('Minimum 1 number is required'); ?></small></p>
                                            <p class="text-danger my-1 special"><small><?php echo app('translator')->get('Minimum 1 special character is required'); ?></small></p>
                                            <p class="text-danger my-1 minimum"><small><?php echo app('translator')->get('Minimum 6 characters'); ?></small></p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password"><?php echo app('translator')->get('Confirm Password'); ?></label>
                                <div class="input-group">
                                    <input id="password_confirmation" placeholder="Confirm Password" type="password" class="form--control" name="password_confirmation" required autocomplete="current-password">

                                    <span class="input-group-text bg--base border--base text-white"><i class="la la-key"></i></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="mt-4 btn w-100 text-white custom--bg" value="<?php echo app('translator')->get('Change Password'); ?>">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script-lib'); ?>
<script src="<?php echo e(asset('assets/global/js/secure_password.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
<script>
    (function ($) {
        "use strict";
        <?php if($general->secure_password): ?>
            $('input[name=password]').on('input',function(){
                secure_password($(this));
            });
        <?php endif; ?>
    })(jQuery);
</script>
<?php $__env->stopPush(); ?>



<?php $__env->startPush('bottom-menu'); ?>
    <li><a href="<?php echo e(route('user.profile.setting')); ?>"><?php echo app('translator')->get('Profile'); ?></a></li>
    <?php if($general->modules->referral_system): ?>
        <li><a href="<?php echo e(route('user.referral.users')); ?>"><?php echo app('translator')->get('Referral'); ?></a></li>
    <?php endif; ?>
    <li><a href="<?php echo e(route('user.twofactor')); ?>"><?php echo app('translator')->get('2FA Security'); ?></a></li>
    <li><a class="active" href="<?php echo e(route('user.change.password')); ?>"><?php echo app('translator')->get('Change Password'); ?></a></li>
    <li><a href="<?php echo e(route('user.transaction.history')); ?>"><?php echo app('translator')->get('Transactions'); ?></a></li>
    <li><a class="<?php echo e(menuActive(['ticket.*'])); ?>" href="<?php echo e(route('ticket')); ?>"><?php echo app('translator')->get('Support Tickets'); ?></a></li>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/password.blade.php ENDPATH**/ ?>