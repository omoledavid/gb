<?php
    $contact = getContent('contact_us.content', true);
    $datas = getContent('contact_us.element');
?>

<?php $__env->startSection('content'); ?>

<section class="pt-100 pb-100">
    <div class="container">
      <div class="row gy-4 justify-content-center pb-50">
        <div class="col-xl-6 col-lg-5 order-lg-1 order-2">
          <div class="map-wrapper">
            <iframe src="<?php echo e(@$contact->data_values->map_source); ?>" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          </div>
        </div>
        <div class="col-xl-6 col-lg-7 order-lg-2 order-1">
          <div class="contact-form-wrapper">
            <h2 class="title"><?php echo e(__(@$contact->data_values->heading)); ?></h2>
            <form action="" method="post">
              <div class="row">
                <div class="col-lg-6 form-group">
                <?php echo csrf_field(); ?>
                  <label for="name"><?php echo app('translator')->get('Name'); ?> *</label>
                  <div class="custom-icon-field">
                    <i class="las la-user"></i>
                    <input name="name" id="name" type="text" placeholder="<?php echo app('translator')->get('Your Name'); ?>" class="form--control" value="<?php echo e(old('name')); ?>" required>
                  </div>
                </div>
                <div class="col-lg-6 form-group">
                  <label for="email"><?php echo app('translator')->get('Email'); ?> *</label>
                  <div class="custom-icon-field">
                    <i class="las la-envelope"></i>
                    <input name="email" id="email" type="text" placeholder="<?php echo app('translator')->get('Enter E-Mail Address'); ?>" class="form--control" value="<?php echo e(old('email')); ?>" required>
                  </div>
                </div>
                <div class="col-lg-12 form-group">
                    <label for="subject"><?php echo app('translator')->get('Subject'); ?> *</label>
                    <div class="custom-icon-field">
                      <i class="las la-clipboard-list"></i>
                      <input name="subject" id="subject" type="text" placeholder="<?php echo app('translator')->get('Write your subject'); ?>" class="form--control" value="<?php echo e(old('subject')); ?>" required>
                    </div>
                </div>
                <div class="col-lg-12 form-group">
                  <label><?php echo app('translator')->get('Message'); ?> *</label>
                  <div class="custom-icon-field">
                    <textarea name="message" wrap="off" placeholder="<?php echo app('translator')->get('Write your message'); ?>" class="form--control"><?php echo e(old('message')); ?></textarea>
                    <i class="las la-comment"></i>
                  </div>
                </div>
                <div class="col-lg-12">
                  <button type="submit" class="btn btn--gradient"><?php echo app('translator')->get('Submit Now'); ?></button>
                </div>
              </div>
            </form>
          </div><!-- contact-form-wrapper end -->
        </div>
      </div><!-- row end -->
      <h3 class="fw-bold mb-4"><?php echo app('translator')->get('Quick'); ?> <br> <?php echo app('translator')->get('Information'); ?></h3>
      <div class="row gy-4 justify-content-center">

        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6">
          <div class="contact-info-card gradient--bg">
            <div class="contact-info-card__icon">
              <?php echo $data->data_values->icon ?>
            </div>
            <div class="contact-info-card__content">
              <h4 class="title"><?php echo e(__($data->data_values->address_type)); ?></h4>
              <a href="javascript:void(0)"><?php echo e(__($data->data_values->address)); ?></a>
            </div>
          </div><!-- contact-info-card end -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div><!-- row end -->
    </div>
  </section>

  <!-- hero section end -->
<?php if($sections->secs != null): ?>
<?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make($activeTemplate.'sections.'.$sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\2024\Jan\trustspring\core\resources\views/templates/basic/contact.blade.php ENDPATH**/ ?>