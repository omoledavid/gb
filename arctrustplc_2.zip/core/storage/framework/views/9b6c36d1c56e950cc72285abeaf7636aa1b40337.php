<?php $__env->startSection('content'); ?>

<?php
    $signupBg = getContent('signup_bg.content', true);
    $links = getContent('pages.element');
?>

  <section class="account-section registration-section bg_img" style="background-image: url(' <?php echo e(getImage( 'assets/images/frontend/signup_bg/' .@$signupBg->data_values->image, '1920x1280')); ?> ');">
    <div class="account-section-left">
        <div class="account-section-left-inner">
            <h4 class="title text-white mb-2"><?php echo e(__(@$signupBg->data_values->heading)); ?></h4>
            <p class="text-white"><?php echo e(__(@$signupBg->data_values->subheading)); ?></p>

            <p class="mt-xl-5 mt-3 text-white"><?php echo app('translator')->get("Have an account"); ?>? <a href="<?php echo e(route('user.login')); ?>" class="text--base"><?php echo app('translator')->get('Login here'); ?></a></p>
        </div>
    </div>
    <div class="account-section-right">
        <div class="top text-center">
            <a href="<?php echo e(route('home')); ?>" class="account-logo">
                <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="logo">
            </a>
        </div>
        <div class="middle">
            <form class="account-form" action="<?php echo e(route('user.register')); ?>" method="POST" onsubmit="return submitUserForm();">
                <div class="row">
                    <?php echo csrf_field(); ?>

                    <?php if(session()->get('reference') != null && $general->modules->referral_system): ?>
                        <h6 class="text-white text-center mb-3"><?php echo app('translator')->get('Referred By'); ?>: <?php echo e(session()->get('reference')); ?></h6>
                    <?php endif; ?>

                    <div class="col-lg-6 form-group">
                        <label for="firstname"><?php echo app('translator')->get('First Name'); ?> *</label>
                        <input id="firstname" placeholder="First Name" type="text" class="form--control" name="firstname" value="<?php echo e(old('firstname')); ?>" required>
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="lastname"><?php echo app('translator')->get('Last Name'); ?> *</label>
                        <input id="lastname" placeholder="Last Name" type="text" class="form--control" name="lastname" value="<?php echo e(old('lastname')); ?>" required>
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="username"><?php echo app('translator')->get('Username'); ?> *</label>
                        <input id="username" id="username" type="text" class="form--control checkUser" name="username" value="<?php echo e(old('username')); ?>" placeholder="<?php echo app('translator')->get('Enter username'); ?>" required>
                        <small class="text-danger usernameExist"></small>
                    </div>
                    <div class="col-lg-6 form-group">
                        <label for="email"><?php echo app('translator')->get('E-Mail Address'); ?> *</label>
                        <input id="email" type="email" class="form--control checkUser" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo app('translator')->get('Enter email address'); ?>" required>
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="lastname"><?php echo app('translator')->get('Country'); ?> *</label>
                        <select name="country" id="country" class="form--control">
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option data-mobile_code="<?php echo e($country->dial_code); ?>" value="<?php echo e($country->country); ?>" data-code="<?php echo e($key); ?>"><?php echo e(__($country->country)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="mobile"><?php echo app('translator')->get('Mobile'); ?> *</label>
                        <div class="input-group">

                            <span class="input-group-text bg--base border--base text-white">
                            <span name="moblie" class="border-0 bg-transparent mobile-code">

                            </span>
                            <input type="hidden" name="mobile_code">
                            <input type="hidden" name="country_code">
                            </span>

                            <input type="text" name="mobile" id="mobile" value="<?php echo e(old('mobile')); ?>" class="form--control checkUser" placeholder="<?php echo app('translator')->get('Your Phone Number'); ?>" required>
                        </div>
                        <small class="text-danger mobileExist"></small>
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="city"><?php echo app('translator')->get('City'); ?> *</label>
                        <input id="city" id="city" type="text" class="form--control checkUser" name="city" value="<?php echo e(old('city')); ?>" placeholder="<?php echo app('translator')->get('Enter City'); ?>" required>
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="zip"><?php echo app('translator')->get('Zip Code'); ?> *</label>
                        <input id="zip" id="zip" type="text" class="form--control checkUser" name="zip" value="<?php echo e(old('zip')); ?>" placeholder="<?php echo app('translator')->get('Enter Zip'); ?>" required>
                    </div>

                    <div class="col-lg-12 form-group">
                        <label for="address"><?php echo app('translator')->get('Address'); ?> *</label>
                        <input id="address" id="address" type="text" class="form--control checkUser" name="address" value="<?php echo e(old('address')); ?>" placeholder="<?php echo app('translator')->get('Enter Address'); ?>" required>
                    </div>


                    <div class="col-lg-6 form-group hover-input-popup">
                        <label for="password"><?php echo app('translator')->get('Password'); ?> *</label>
                        <input type="password" id="password" name="password" autocomplete="off" class="form--control" placeholder="<?php echo app('translator')->get('Enter Password'); ?>">
                        <?php if($general->secure_password): ?>
                        <div class="input-popup">
                            <p class="text-danger my-1 capital"><small><?php echo app('translator')->get('Minimum 1 capital letter is required'); ?></small></p>
                            <p class="text-danger my-1 lower"><small><?php echo app('translator')->get('Minimum 1 small letter is required'); ?></small></p>
                            <p class="text-danger my-1 number"><small><?php echo app('translator')->get('Minimum 1 number is required'); ?></small></p>
                            <p class="text-danger my-1 special"><small><?php echo app('translator')->get('Minimum 1 special character is required'); ?></small></p>
                            <p class="text-danger my-1 minimum"><small><?php echo app('translator')->get('Minimum 6 characters'); ?></small></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-6 form-group">
                        <label for="password-confirm"><?php echo app('translator')->get('Confirm Password'); ?> *</label>
                        <input id="password-confirm" type="password" class="form--control" name="password_confirmation" required autocomplete="new-password" placeholder="<?php echo app('translator')->get('Confirm password'); ?>">
                    </div>

                    <?php echo loadReCaptcha() ?>

                    <?php echo $__env->make($activeTemplate.'partials.custom_captcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php if($general->agree): ?>
                        <div class="col-lg-12 form-group">
                            <div class="form-check custom--checkbox">
                                <input type="checkbox" class="form-check-input" id="agree" name="agree" required>
                                <label for="agree" class="form-check-label">
                                    <?php echo app('translator')->get('I agree with'); ?>
                                    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('page', [$link->id,slug($link->data_values->title)])); ?>" target="blank" class="text--base">
                                        <?php echo e(__($link->data_values->title)); ?></a>
                                        <?php echo e($loop->last ? '.' : ','); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </label>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="col-lg-12">
                        <button type="submit" class="btn btn--base text-white w-100"><?php echo app('translator')->get('Sign Up'); ?></button>
                    </div>

                </div>
            </form>
        </div>
        <div class="bottom">
            <div class="row">
                <div class="col-xl-12">
                    <ul class="d-flex flex-wrap align-items-center account-short-link justify-content-center">
                            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('page', [$link->id,slug($link->data_values->title)])); ?>" target="blank">
                        <?php echo e(__($link->data_values->title)); ?></a>
                        <?php echo e($loop->last ? '.' : ','); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('modal'); ?>
<div class="modal fade" id="existModalCenter" tabindex="-1" role="dialog" aria-labelledby="existModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="existModalLongTitle"><?php echo app('translator')->get('You are with us'); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <h6 class="text-center"><?php echo app('translator')->get('You have been already signing up with us'); ?></h6>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-md btn-danger" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
          <a href="<?php echo e(route('user.login')); ?>" class="btn btn-md custom--bg text-white"><?php echo app('translator')->get('Login'); ?></a>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('style'); ?>
<style>
    .country-code .input-group-prepend .input-group-text{
        background: #fff !important;
    }
    .country-code select{
        border: none;
    }
    .country-code select:focus{
        border: none;
        outline: none;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
<script src="<?php echo e(asset('assets/global/js/secure_password.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script>

      "use strict";

      function submitUserForm() {
            var response = grecaptcha.getResponse();
            if (response.length == 0) {
                document.getElementById('g-recaptcha-error').innerHTML = '<span class="text-danger"><?php echo app('translator')->get("Captcha field is required."); ?></span>';
                return false;
            }
            return true;
        }
        (function ($) {
            <?php if($mobile_code): ?>
            $(`option[data-code=<?php echo e($mobile_code); ?>]`).attr('selected','');
            <?php endif; ?>

            $('select[name=country]').change(function(){
                $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
                $('input[name=country_code]').val($('select[name=country] :selected').data('code'));
                $('.mobile-code').text('+'+$('select[name=country] :selected').data('mobile_code'));
            });
            $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
            $('input[name=country_code]').val($('select[name=country] :selected').data('code'));
            $('.mobile-code').text('+'+$('select[name=country] :selected').data('mobile_code'));
            <?php if($general->secure_password): ?>
                $('input[name=password]').on('input',function(){
                    secure_password($(this));
                });
            <?php endif; ?>

            $('.checkUser').on('focusout',function(e){
                var url = '<?php echo e(route('user.checkUser')); ?>';
                var value = $(this).val();
                var token = '<?php echo e(csrf_token()); ?>';
                if ($(this).attr('name') == 'mobile') {
                    var mobile = `${$('.mobile-code').text().substr(1)}${value}`;
                    var data = {mobile:mobile,_token:token}
                }
                if ($(this).attr('name') == 'email') {
                    var data = {email:value,_token:token}
                }
                if ($(this).attr('name') == 'username') {
                    var data = {username:value,_token:token}
                }
                $.post(url,data,function(response) {
                  if (response['data'] && response['type'] == 'email') {
                    $('#existModalCenter').modal('show');
                  }else if(response['data'] != null){
                    $(`.${response['type']}Exist`).text(`${response['type']} already exist`);
                  }else{
                    $(`.${response['type']}Exist`).text('');
                  }
                });
            });

        })(jQuery);

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/auth/register.blade.php ENDPATH**/ ?>