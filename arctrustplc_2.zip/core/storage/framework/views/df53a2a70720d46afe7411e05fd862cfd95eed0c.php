<?php $__env->startSection('panel'); ?>
    <div class="row">

        <div class="col-lg-12">
            <div class="card">
                <div class="card-body p-0">
                    <div class="table-responsive--sm table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Bank'); ?></th>
                                <th class="text-left"><?php echo app('translator')->get('Transfer Limit'); ?></th>
                                <th class="text-left"><?php echo app('translator')->get('Transfer Charge'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Bank'); ?>">
                                        <div class="text--primary font-weight-bold">
                                            <?php echo e(__($data->name)); ?>

                                        </div>
                                        <?php echo app('translator')->get('Processing Time'); ?> : <?php echo e($data->processing_time); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Transfer Limit'); ?>" class="text-left">
                                        <div>
                                            <?php echo app('translator')->get('Min'); ?> :
                                            <strong class="text--primary">
                                                <?php echo e($general->cur_sym.showAmount($data->minimum_limit)); ?>

                                            </strong>
                                        </div>
                                        <div>
                                            <?php echo app('translator')->get('Max'); ?> :
                                            <strong class="text--primary">
                                                <?php echo e($general->cur_sym.showAmount($data->maximum_limit)); ?>

                                            </strong>
                                        </div>

                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Transfer Charge'); ?>" class="text-left">
                                        <div>
                                            <?php echo app('translator')->get('Fixed'); ?> :
                                            <strong class="text--primary">
                                                <?php echo e($general->cur_sym.showAmount($data->fixed_charge)); ?>

                                            </strong>
                                        </div>
                                        <div>
                                            <?php echo app('translator')->get('Percent'); ?> :
                                            <strong class="text--primary">
                                                <?php echo e(getAmount($data->percent_charge)); ?>%
                                            </strong>
                                        </div>
                                    </td>


                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                        <?php if($data->status == 1): ?>
                                            <span class="text--small badge font-weight-normal badge--success"><?php echo app('translator')->get('Enabled'); ?></span>
                                        <?php else: ?>
                                            <span class="text--small badge font-weight-normal badge--danger"><?php echo app('translator')->get('Disabled'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">

                                        <a href="<?php echo e(route('admin.bank.edit', $data->id)); ?>"
                                           class="icon-btn ml-1 editBtn" data-toggle="tooltip" title=""
                                           data-original-title="<?php echo app('translator')->get('Edit'); ?>">
                                            <i class="la la-pencil"></i>
                                        </a>

                                        <a href="javascript:void(0)"
                                           data-id="<?php echo e($data->id); ?>"
                                           data-status="<?php echo e($data->status); ?>"
                                           class="icon-btn statusBtn <?php echo e($data->status == 1 ? 'bg--danger' : 'bg--success'); ?> ml-1" data-toggle="tooltip" title="<?php if($data->status == 1): ?> <?php echo app('translator')->get('Disable'); ?> <?php else: ?> <?php echo app('translator')->get('Enable'); ?> <?php endif; ?>">
                                            <i class="la la-<?php echo e($data->status == 1 ? 'la la-eye-slash' : 'la la-eye'); ?>"></i>
                                        </a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
                <?php if($banks->hasPages()): ?>
                <div class="card-footer py-4">
                    <?php echo e(paginateLinks($banks)); ?>

                </div>
                <?php endif; ?>
            </div><!-- card end -->
        </div>
    </div>



<div id="statusModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo app('translator')->get('Confirmation Alert'); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('admin.bank.status')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                <div class="modal-body">
                    <p><?php echo app('translator')->get('Are you sure to'); ?> <span class="font-weight-bold method-name"></span> <?php echo app('translator')->get(' this item'); ?>?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('No'); ?></button>
                    <button type="submit" class="btn btn--primary">Yes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>

    <div class="d-flex justify-content-end align-items-center">
        <form action="" method="GET" class="form-inline float-sm-right bg--white mr-2">
            <div class="input-group has_append">
                <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('Bank Name'); ?>" value="<?php echo e(request()->search ?? ''); ?>">
                <div class="input-group-append">
                    <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
                </div>
            </div>
        </form>

        <a href="<?php echo e(route('admin.bank.create')); ?>" class="btn btn--primary box--shadow1 text-white text--small"><i class="fa fa-fw fa-plus"></i><?php echo app('translator')->get('Add New'); ?></a>

    </div>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script>
    (function ($) {

        "use strict";

        $('.statusBtn').on('click', (e)=> {
            var btn     = $(e.currentTarget);
            var modal   = $('#statusModal');
            var status  = btn.data('status');
            var message = status == 1 ? '<?php echo app('translator')->get("Are you sure to disable this bank?"); ?>':'<?php echo app('translator')->get("Are you sure to enable this bank?"); ?>';
            modal.find('.modal-body').text(message);
            modal.find('input[name=id]').val(btn.data('id'));
            modal.modal('show');
        });

    })(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/admin/other_banks/index.blade.php ENDPATH**/ ?>