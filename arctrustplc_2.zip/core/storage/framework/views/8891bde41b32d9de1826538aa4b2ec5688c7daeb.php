<?php
    $overview   = getContent('overview.content', true);
    $elements      = getContent('overview.element', false, 4, true);
?>

<!-- overview section start -->
<section class="overview-section pt-100 pb-50">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8 col-lg-10">
                <div class="section-header text-center">
                    <h2 class="section-title text-white"><?php echo e(__(@$overview->data_values->heading)); ?></h2>
                    <p class="mt-3 text-white"><?php echo e(__(@$overview->data_values->subheading)); ?></p>
                </div>
            </div>
        </div><!-- row end -->

        <div class="overview-area wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">
            <div class="row gy-4 justify-content-center">

                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-6">
                        <div class="overview-card">
                            <div class="overview-card__icon">
                                <?php echo $element->data_values->icon ?>
                            </div>
                            <div class="overview-card__content">
                                <h4 class="couter-number"><?php echo e(__($element->data_values->heading)); ?></h4>
                                <p><?php echo e(__($element->data_values->subheading)); ?></p>
                            </div>
                        </div><!-- overview-card end -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div><!-- overview-area end -->
    </div>
</section>
<!-- overview section end -->
<?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/sections/overview.blade.php ENDPATH**/ ?>