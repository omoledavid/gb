<?php
    $work = getContent('how_it_work.content', true);
    $elements = getContent('how_it_work.element', false, null, true);
?>

<!-- how work section start -->
    <section id="how-work" class="pt-50 pb-50 section--bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                <div class="section-header text-center">
                    <div class="section-top-title border-left custom--cl"><?php echo e(__(@$work->data_values->title)); ?></div>
                    <h2 class="section-title"><?php echo e(__(@$work->data_values->heading)); ?></h2>
                </div>
                </div>
            </div><!-- row end -->
            <div class="row gy-4">
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-6 how-work-item wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.3s">
                        <div class="how-work-card">
                            <div class="how-work-card__step"><?php echo e($loop->iteration); ?></div>
                            <h3 class="title mt-4"><?php echo e(__($element->data_values->heading)); ?></h3>
                            <p class="mt-2"><?php echo e(__($element->data_values->subheading)); ?></p>
                        </div><!-- how-work-card end -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
      </section>
      <!-- how work section end -->
<?php /**PATH C:\xampp\htdocs\work\2024\Jan\trustspring\core\resources\views/templates/basic/sections/how_it_work.blade.php ENDPATH**/ ?>