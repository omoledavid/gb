<?php $__env->startSection('content'); ?>

<!-- dashboard section start -->
<div class="container">
    <div class="row justify-content-center mb-none-30">
        <div class="col-lg-12">
            <div class="custom--card">
                <div class="table-responsive--md">
                    <table class="table custom--table">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Date'); ?></th>
                                <th><?php echo app('translator')->get('Trx'); ?></th>
                                <th><?php echo app('translator')->get('Details'); ?></th>
                                <th><?php echo app('translator')->get('Amount'); ?></th>
                                <th><?php echo app('translator')->get('Post Balance'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="Date">
                                        <?php echo e(showDateTime($data->created_at, 'd M, Y h:i A')); ?>

                                    </td>
                                    <td data-label="Trx">
                                        <?php echo e($data->trx); ?>

                                    </td>

                                    <td data-label="Details">
                                        <?php echo e(__($data->details)); ?>

                                    </td>

                                    <td data-label="Amount" class="fw-bold <?php if($data->trx_type == '-'): ?> text--danger <?php endif; ?>">
                                        <?php echo e($data->trx_type); ?>

                                        <?php echo e(showAmount($data->amount)); ?>

                                        <?php echo e(__($general->cur_text)); ?>

                                    </td>
                                    <td data-label="Post Balance">
                                        <?php echo e(showAmount($data->post_balance)); ?>

                                        <?php echo e(__($general->cur_text)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                    <?php echo e($histories->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <!-- dashboard section end -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('bottom-menu'); ?>
    <li><a href="<?php echo e(route('user.profile.setting')); ?>"><?php echo app('translator')->get('Profile'); ?></a></li>
    <?php if($general->modules->referral_system): ?>
        <li><a href="<?php echo e(route('user.referral.users')); ?>"><?php echo app('translator')->get('Referral'); ?></a></li>
    <?php endif; ?>
    <li><a href="<?php echo e(route('user.twofactor')); ?>"><?php echo app('translator')->get('2FA Security'); ?></a></li>
    <li><a href="<?php echo e(route('user.change.password')); ?>"><?php echo app('translator')->get('Change Password'); ?></a></li>
    <li><a class="active" href="<?php echo e(route('user.transaction.history')); ?>"><?php echo app('translator')->get('Transactions'); ?></a></li>
    <li><a class="<?php echo e(menuActive(['ticket.*'])); ?>" href="<?php echo e(route('ticket')); ?>"><?php echo app('translator')->get('Support Tickets'); ?></a></li>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/transactions.blade.php ENDPATH**/ ?>