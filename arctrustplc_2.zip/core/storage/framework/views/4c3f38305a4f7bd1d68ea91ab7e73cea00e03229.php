<?php $__env->startSection('content'); ?>


<!-- dashboard section start -->
    <div class="container">

        <div class="row align-items-center mb-3">
            <div class="col-6">
                <h6><?php echo app('translator')->get('My Withdrawal History'); ?></h6>
            </div>
            <div class="col-6 text-end">
                <button type="button" data-bs-toggle="modal" data-bs-target="#withdrawModal" class="btn btn-sm btn--base"><i class="las la-minus-circle"></i> <?php echo app('translator')->get('Withdraw Now'); ?></button>
            </div>
        </div>

      <div class="row justify-content-center mb-none-30">
        <div class="col-lg-12">
          <div class="custom--card">
              <div class="card-body p-0">
                <div class="table-responsive--md">
                    <table class="table custom--table">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Method | TRX'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Amount | Charge'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Rate'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Final Amount'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Date'); ?>">
                                    <?php echo e(showDateTime($data->created_at, 'd M, Y h:i A')); ?>

                                    <span class="d-block"><?php echo e(diffForHumans($data->created_at)); ?></span>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Method | TRX'); ?>">
                                    <span class="d-block text--base"><?php echo e(__($data->method->name)); ?></span>
                                    <small class="d-block">
                                        <?php echo e($data->trx); ?>

                                    </small>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Amount | Charge'); ?>">
                                    <span class="d-block text--base"><?php echo e(showAmount($data->amount)); ?> <?php echo e(__($general->cur_text)); ?></span>
                                    <span class="d-block text--danger"><?php echo e(showAmount($data->charge)); ?> <?php echo e(__($general->cur_text)); ?></span>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Rate'); ?>">
                                    <?php echo app('translator')->get('Per'); ?> <?php echo app('translator')->get($general->cur_text); ?>
                                    <span class="d-block text--base">
                                        <?php echo e(showAmount($data->rate)); ?> <?php echo e(__($data->currency)); ?>

                                    </span>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Final Amount'); ?>">
                                    <span class="d-block"><?php echo e(showAmount($data->after_charge)); ?> <?php echo e(__($general->cur_text)); ?></span>

                                    <span class="d-block text--base"><?php echo e(showAmount($data->final_amount)); ?> <?php echo e(__($data->currency)); ?></span>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($data->status == 2): ?>
                                        <span class="badge badge--warning"><?php echo app('translator')->get('Pending'); ?></span>
                                    <?php elseif($data->status == 1): ?>
                                        <span class="badge badge--success"><?php echo app('translator')->get('Completed'); ?>
                                            <button class="bg-transparent text-info approveBtn" data-admin_feedback="<?php echo e($data->admin_feedback); ?>"><i class="fa fa-info-circle"></i></button>
                                        </span>
                                    <?php elseif($data->status == 3): ?>
                                        <span class="badge badge--danger"><?php echo app('translator')->get('Rejected'); ?>
                                            <button class="bg-transparent text-info approveBtn" data-admin_feedback="<?php echo e($data->admin_feedback); ?>"><i class="fa fa-info-circle"></i></button>
                                        </span>
                                    <?php endif; ?>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>

                    </table>
                    <?php echo e($withdraws->links()); ?>

                </div>
              </div>
          </div>
        </div>
    </div>
  <!-- dashboard section end -->


<?php $__env->stopSection(); ?>


<?php $__env->startPush('modal'); ?>

<div id="detailModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo app('translator')->get('Details'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="withdraw-detail"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-md btn-danger" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
            </div>
        </div>
    </div>
</div>

<div id="withdrawModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Withdraw Money'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('user.action')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" value="withdraw">

                    <div class="modal-body">
                        <div class="form-group">
                            <label for="paymentGateway" class="fw-bold"><?php echo app('translator')->get('Withdraw Method'); ?></label>
                            <select class="form--control" name="id" id="paymentGateway" required>
                                <option disabled selected value=""><?php echo app('translator')->get('Select One'); ?></option>
                                <?php $__currentLoopData = $withdrawMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option data-currency="<?php echo e($gateway->currency); ?>"
                                        data-min_amount="<?php echo e(getAmount($gateway->min_limit)); ?>"
                                        data-max_amount="<?php echo e(getAmount($gateway->max_limit)); ?>"
                                        data-fix_charge="<?php echo e(getAmount($gateway->fixed_charge)); ?>"
                                        data-percent_charge="<?php echo e(getAmount($gateway->percent_charge)); ?>"
                                        value="<?php echo e($gateway->id); ?>">
                                        <?php echo app('translator')->get($gateway->name); ?>
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <div  class="mt-3">
                                <p><small class="text--danger limit-info"></small></p>
                                <p><small class="text-danger charge-info"></small></p>
                            </div>

                        </div>
                        <div class="form-group">
                            <label class="fw-bold" for="amount"><?php echo app('translator')->get('Amount'); ?></label>
                            <div class="input-group">
                                <input id="amount" type="text" class="form--control numeric-validation" name="amount" placeholder="0.00" value="<?php echo e(old('amount')); ?>" required>
                                <span class="input-group-text bg--base text-white border--base"><?php echo e(__($general->cur_text)); ?></span>
                            </div>
                        </div>

                        <?php if(checkIsOtpEnable($general)): ?>
                            <?php echo $__env->make($activeTemplate.'partials.otp_field', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger btn-md" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--base btn-md"><?php echo app('translator')->get('Confirm'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        (function($){
            "use strict";
            $('.approveBtn').on('click', function() {
                var modal = $('#detailModal');
                var feedback = $(this).data('admin_feedback');

                modal.find('.withdraw-detail').html(`<p> ${feedback} </p>`);
                modal.modal('show');
            });

            $('#paymentGateway').on('change', function(){
                let option = $(this).find('option:selected');
                var minAmount       = option.data('min_amount');
                var maxAmount       = option.data('max_amount');
                var baseSymbol      = "<?php echo e($general->cur_text); ?>";
                var fixCharge       = option.data('fix_charge');
                var percentCharge   = option.data('percent_charge');
                var limitInfo       = `<?php echo app('translator')->get('Deposit Limit'); ?>: ${minAmount} - ${maxAmount}  ${baseSymbol}`;
                $('.limit-info').text(limitInfo);
                var chargeInfo = `<?php echo app('translator')->get('Charge'); ?>: ${fixCharge} ${baseSymbol}  ${(0 < percentCharge) ? ' + ' +percentCharge + ' % ' : ''}`;


                $('.charge-info').text(chargeInfo);
            });

        })(jQuery);

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/withdraw/log.blade.php ENDPATH**/ ?>