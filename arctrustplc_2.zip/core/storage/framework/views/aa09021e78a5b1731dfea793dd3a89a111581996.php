<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="custom--card">
            <div class="table-responsive--md mt-3">
                <table class="table custom--table">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->get('Acccount Name'); ?></th>
                            <th><?php echo app('translator')->get('Short Name'); ?></th>
                            <th><?php echo app('translator')->get('Account Number'); ?></th>
                            <th><?php echo app('translator')->get('Bank'); ?></th>
                            <th><?php echo app('translator')->get('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $beneficiaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('Acccount Name'); ?>">
                                <?php echo e($beneficiary->short_name); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Short Name'); ?>">
                                <?php echo e($beneficiary->account_name); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Account Number'); ?>">
                                <?php echo e($beneficiary->account_number); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Bank'); ?>">
                                <?php echo e($beneficiary->bank->name); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                <span data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo app('translator')->get('Details'); ?>">
                                    <button class="btn btn-sm btn--base seeDetails"
                                        data-bank_name="<?php echo e($beneficiary->bank->name); ?>"
                                        data-short_name="<?php echo e($beneficiary->short_name); ?>"
                                        data-details='<?php echo json_encode($beneficiary->details, 15, 512) ?>'

                                    >
                                        <i class="la la-desktop"></i>
                                    </button>
                                </span>

                                <span data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo app('translator')->get('Transfer Money'); ?>">
                                    <button type="button"
                                    data-name="<?php echo e($beneficiary->short_name); ?>"
                                    data-bank_name="<?php echo e($beneficiary->bank->name); ?>"
                                    daa
                                    data-id="<?php echo e($beneficiary->id); ?>"

                                    data-minimum_amount="<?php echo e($general->cur_sym.showAmount($beneficiary->bank->minimum_limit)); ?>"
                                    data-maximum_amount="<?php echo e($general->cur_sym.showAmount($beneficiary->bank->maximum_limit)); ?>"
                                    data-daily_limit="<?php echo e($general->cur_sym.showAmount($beneficiary->bank->daily_maximum_limit)); ?>"
                                    data-monthly_limit="<?php echo e($general->cur_sym.showAmount($beneficiary->bank->monthly_maximum_limit)); ?>"
                                    data-daily_count="<?php echo e($beneficiary->bank->daily_total_transaction); ?>"
                                    data-monthly_count="<?php echo e($beneficiary->bank->monthly_total_transaction); ?>"
                                        class="btn btn-sm btn--base sendBtn"
                                    >
                                        <i class="las la-random"></i>
                                    </button>
                                </span>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="100%" class="text-center"><?php echo app('translator')->get($emptyMessage); ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php echo e($beneficiaries->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('bottom-menu'); ?>
    <?php if($general->modules->own_bank || $general->modules->other_bank): ?>
        <li>
            <a href="<?php echo e(route('user.transfer.beneficiary.manage')); ?>"><?php echo app('translator')->get('Beneficiary Management'); ?></a>
        </li>
        <?php if($general->modules->own_bank): ?>
            <li>
                <a href="<?php echo e(route('user.transfer.own')); ?>"><?php echo app('translator')->get('Transfer Within'); ?> <?php echo app('translator')->get($general->sitename); ?></a>
            </li>
        <?php endif; ?>
        <?php if($general->modules->other_bank): ?>
            <li>
                <a class="active" href="<?php echo e(route('user.transfer.other')); ?>"><?php echo app('translator')->get('Transfer To Other Bank'); ?></a>
            </li>
        <?php endif; ?>

        <li>
            <a href="<?php echo e(route('user.transfer.history')); ?>"><?php echo app('translator')->get('Transfer History'); ?></a>
        </li>

    <?php endif; ?>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('modal'); ?>
    <!-- Modal -->
    <div class="modal fade" id="detailsModal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Benficiary Details'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <ul class="list-group list-group-flush">
                    </ul>
                </div>

            </div>
        </div>
    </div>



    <div class="modal fade" id="sendModal">
        <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Transfer Money'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="<?php echo e(route('user.action')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-xl-5 mb-3">
                                <div class="card shadow-none">
                                    <div class="card-header bg--dark">
                                        <h5 class="border-0 py-1 px-2 text-white"><?php echo app('translator')->get('Transfer Limit'); ?></h5>
                                    </div>
                                    <div class="card-body">
                                        <ul class="caption-list-two">
                                            <li>
                                                <span class="caption"><?php echo app('translator')->get('Minimum Amount'); ?></span>
                                                <span class="value minimum_amount"></span>
                                            </li>
                                            <li>
                                                <span class="caption"><?php echo app('translator')->get('Maximum Amount'); ?></span>
                                                <span class="value maximum_amount"></span>
                                            </li>

                                            <li>
                                                <span class="caption"><?php echo app('translator')->get('Daily Available'); ?></span>
                                                <span class="value daily_limit"></span>
                                            </li>

                                            <li>
                                                <span class="caption"><?php echo app('translator')->get('Monthly Available'); ?></span>
                                                <span class="value monthly_limit"></span>
                                            </li>

                                            <li>
                                                <span class="caption"><?php echo app('translator')->get('Daily Available Count'); ?></span>
                                                <span class="value daily_count"></span>
                                            </li>

                                            <li>
                                                <span class="caption"> <?php echo app('translator')->get('Monthly Available Count'); ?></span>
                                                <span class="value monthly_count"></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-7">

                                <input type="hidden" name="id">
                        <input type="hidden" name="type" value="other_transfer">

                        <div class="form-group">
                            <label><?php echo app('translator')->get('Bank'); ?></label>
                            <input type="text" class="bank-name form--control" class="form-control" readonly>
                        </div>

                        <div class="form-group">
                            <label><?php echo app('translator')->get('Recipient'); ?></label>
                            <input type="text" class="short-name form--control" class="form-control" readonly>
                        </div>

                        <div class="form-group">
                            <label><?php echo app('translator')->get('Amount'); ?></label>
                            <div class="input-group">
                                <input type="text" name="amount" placeholder="<?php echo app('translator')->get('Enter an Amount'); ?>" class="form--control numeric-validation" required >
                                <span class="input-group-text bg--base text-white border--base"><?php echo app('translator')->get($general->cur_text); ?></span>
                            </div>
                        </div>

                        <?php if(checkIsOtpEnable($general)): ?>
                            <?php echo $__env->make($activeTemplate.'partials.otp_field', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                            </div>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn--danger" data-bs-dismiss="modal"><?php echo app('translator')->get('Cancel'); ?></button>
                        <button type="submit" class="btn btn-sm btn--base"><?php echo app('translator')->get('Send'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        (function($){

            $('.sendBtn').on('click', function(){
                let modal = $('#sendModal');
                console.log($(this).data('minimum_amount'));
                modal.find('.minimum_amount').text($(this).data('minimum_amount'));
                modal.find('.maximum_amount').text($(this).data('maximum_amount'));
                modal.find('.daily_limit').text($(this).data('daily_limit'));
                modal.find('.monthly_limit').text($(this).data('monthly_limit'));
                modal.find('.daily_count').text($(this).data('daily_count'));
                modal.find('.monthly_count').text($(this).data('monthly_count'));

                modal.find('.bank-name').val($(this).data('bank_name'));
                modal.find('.short-name').val($(this).data('name'));
                modal.find('input[name=id]').val($(this).data('id'));
                modal.modal('show');
            });

            $('.seeDetails').on('click', function(){
                let modal       = $('#detailsModal');
                let details     = $(this).data('details');
                let imagePath   = "<?php echo e(asset(imagePath()['transfer']['beneficiary_data']['path'])); ?>/";
                let html    = `
                    <li class="list-group-item d-flex flex-wrap justify-content-between">
                        <span><?php echo app('translator')->get('Bank Name'); ?></span>
                        ${$(this).data('bank_name')}
                    </li>
                    <li class="list-group-item d-flex flex-wrap justify-content-between">
                        <span><?php echo app('translator')->get('Short Name'); ?></span>
                        ${$(this).data('short_name')}
                    </li>
                `;


                $.each(details, function (i, value) {
                    if(value.type == 'file'){
                        html +=
                        `
                            <li class="list-group-item d-flex flex-wrap justify-content-between">
                                <span><?php echo app('translator')->get('${titleCase(i)}'); ?></span>
                                <img class="w-75" src="${imagePath}${value.value}">
                            </li>
                        `;
                    }else {
                        html +=
                        `
                            <li class="list-group-item d-flex flex-wrap justify-content-between">
                                <span><?php echo app('translator')->get('${titleCase(i)}'); ?></span>
                                ${value.value}
                            </li>
                        `
                    }
                });
                modal.find('.modal-body .list-group').html(html);
                modal.modal('show');
            });
        })(jQuery)

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/transfers/other.blade.php ENDPATH**/ ?>