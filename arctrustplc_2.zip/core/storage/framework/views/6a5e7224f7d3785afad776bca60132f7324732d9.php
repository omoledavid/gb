<?php
    $features = getContent('feature.element');
?>

<div class="feature-section pb-100">
    <div class="container">
        <div class="row gy-4">
            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-sm-6 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">
                <div class="feature-card rounded-3">
                    <div class="icon">
                        <?php echo $feature->data_values->icon ?>
                    </div>
                    <h3 class="title"><?php echo e(__($feature->data_values->heading)); ?></h3>
                    <p><?php echo e(__($feature->data_values->subheading)); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\work\2024\Jan\trustspring\core\resources\views/templates/basic/sections/feature.blade.php ENDPATH**/ ?>