<?php
    $pricing    = getContent('dps_plans.content', true);
    $plans      = App\Models\DpsPlan::active()->latest()->limit(3)->get();
?>

<?php if($plans->count()): ?>
    <section class="pt-100 pb-100 section--bg">
        <div class="container">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-5 col-lg-7">
                        <div class="section-header text-center">
                            <div class="section-top-title border-left custom--cl"><?php echo e(__(@$pricing->data_values->heading)); ?></div>
                            <h2 class="section-title"><?php echo e(__(@$pricing->data_values->subheading)); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center gy-4">
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-4 col-md-6">
                            <div class="plan-card rounded-3 wow fadeInUp">
                                <span class="fdr-badge"><?php echo app('translator')->get('DPS'); ?></span>
                                <div class="plan-card__header">
                                    <div class="wave-shape">
                                        <img src="<?php echo e(asset($activeTemplateTrue. 'images/elements/wave.png')); ?>" alt="img">
                                    </div>
                                    <h4 class="plan-name"><?php echo e(__($plan->name)); ?></h4>
                                    <div class="plan-price">
                                        <?php echo e($general->cur_sym.getAmount($plan->per_installment)); ?>

                                        <sub>/<?php echo e($plan->installment_interval); ?><?php echo app('translator')->get('Days'); ?></sub>
                                    </div>
                                </div>
                                <div class="plan-card__body text-center">
                                    <ul class="plan-feature-list">
                                        <li class="d-flex flex-wrap justify-content-between">
                                            <span>
                                                <?php echo app('translator')->get('Interest Rate'); ?>
                                            </span>
                                            <?php echo e(getAmount($plan->interest_rate)); ?>%
                                        </li>

                                        <li class="d-flex flex-wrap justify-content-between">
                                            <span>
                                                <?php echo app('translator')->get('Installment Interval'); ?>
                                            </span>
                                            <?php echo e($plan->installment_interval); ?> <?php echo app('translator')->get('Days'); ?>
                                        </li>

                                        <li class="d-flex flex-wrap justify-content-between">
                                            <span>
                                                <?php echo app('translator')->get('Total Installment'); ?>
                                            </span>
                                            <?php echo e($plan->total_installment); ?>

                                        </li>

                                        <li class="d-flex flex-wrap justify-content-between">
                                            <span>
                                                <?php echo app('translator')->get('Deposit Amount'); ?>
                                            </span>
                                            <?php echo e($general->cur_sym.showAmount($plan->total_installment * $plan->per_installment)); ?>


                                        </li>

                                        <li class="d-flex flex-wrap justify-content-between">
                                            <span>
                                                <?php echo app('translator')->get('You Will Get'); ?>
                                            </span>
                                            <?php echo e($general->cur_sym.showAmount($plan->final_amount)); ?>

                                        </li>
                                    </ul>
                                </div>
                                <div class="plan-card__footer text-center">
                                    <?php if(auth()->guard()->check()): ?>
                                        <button type="button" data-id="<?php echo e($plan->id); ?>" class="btn btn-md w-100 btn--base dpsBtn"><?php echo app('translator')->get('Apply Now'); ?></button>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('user.login')); ?>" class="btn btn-md w-100 btn--base"><?php echo app('translator')->get('Apply Now'); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div><!-- plan-card end -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-12 d-flex justify-content-center">
                        <a href="<?php echo e(route('user.dps.plans')); ?>" class="btn btn--base"><?php echo app('translator')->get('View More'); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php if(auth()->guard()->check()): ?>
        <?php $__env->startPush('modal'); ?>
            <div class="modal fade" id="dpsModal">

                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <strong class="modal-title method-name"><?php echo app('translator')->get('Apply to Open a DPS'); ?></strong>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                            </a>
                        </div>
                        <form action="<?php echo e(route('user.action')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <input type="hidden" name="id">
                                <input type="hidden" name="type" value="dps">
                                <?php if(checkIsOtpEnable($general)): ?>
                                    <?php echo $__env->make($activeTemplate.'partials.otp_field', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php else: ?>
                                    <?php echo app('translator')->get('Are you sure to apply for this plan?'); ?>
                                <?php endif; ?>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-md btn-danger text-white"
                                    data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                                <button type="submit" class="btn btn-md custom--bg text-white"><?php echo app('translator')->get('Confirm'); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>

    <?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            $('.dpsBtn').on('click', (e) => {
                var modal = $('#dpsModal');
                var $this = $(e.currentTarget);
                modal.find('input[name=id]').val($this.data('id'));
                modal.modal('show');
            });
        })(jQuery);
    </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/sections/dps_plans.blade.php ENDPATH**/ ?>