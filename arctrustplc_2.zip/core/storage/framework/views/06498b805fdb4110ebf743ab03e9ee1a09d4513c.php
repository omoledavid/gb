<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center mb-none-30">
        <div class="col-lg-12">
            <div class="custom--card">
                <div class="card-body p-0">
                    <div class="table-responsive--md">
                        <table class="table custom--table">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('Loan No. | Plan'); ?></th>
                                    <th><?php echo app('translator')->get('Amount'); ?></th>
                                    <th><?php echo app('translator')->get('Installment Amount'); ?></th>
                                    <th><?php echo app('translator')->get('Installment'); ?></th>
                                    <th><?php echo app('translator')->get('Next Installment'); ?></th>
                                    <th><?php echo app('translator')->get('Paid'); ?></th>
                                    <th><?php echo app('translator')->get('Status'); ?></th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__empty_1 = true; $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Loan No. | Plan'); ?>">
                                        <strong><?php echo e(__($loan->trx)); ?></strong>
                                        <small class="d-block text--base"><?php echo e(__($loan->plan->name)); ?></small>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                        <strong>
                                            <?php echo e($general->cur_sym.showAmount($loan->amount)); ?>

                                        </strong>
                                        <small class="d-block text--base">
                                            <?php echo e($general->cur_sym.showAmount($loan->final_amount)); ?> <?php echo app('translator')->get('Need to pay'); ?>
                                        </small>

                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Installment Amount'); ?>">
                                        <strong><?php echo e($general->cur_sym.showAmount($loan->per_installment)); ?></strong>
                                        <small class="d-block text--base">
                                            <?php echo app('translator')->get("In Every"); ?> <?php echo e($loan->installment_interval); ?> <?php echo app('translator')->get("Days"); ?>
                                        </small>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Installment'); ?>">
                                        <strong>
                                            <?php echo app('translator')->get('Total'); ?> : <?php echo e($loan->total_installment); ?>

                                        </strong>
                                        <small class="d-block text--base">
                                            <?php echo app('translator')->get('Given'); ?> : <?php echo e($loan->given_installment); ?>

                                        </small>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Next Installment'); ?>">
                                        <?php if($loan->next_installment_date): ?>
                                        <strong><?php echo e(showDateTime($loan->next_installment_date, 'd M, Y')); ?></strong>
                                        <small class="d-block text--base">
                                            <?php echo e(diffForHumans($loan->next_installment_date, 'd M, Y')); ?>

                                        </small>
                                        <?php else: ?>
                                        <?php echo app('translator')->get('...'); ?>
                                        <?php endif; ?>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Paid'); ?>">
                                        <strong><?php echo e($general->cur_sym.showAmount($loan->paid_amount)); ?></strong>
                                        <span class="d-block text--base">
                                            <?php
                                                $remainingAmount = $loan->final_amount - $loan->paid_amount;
                                            ?>
                                            <small class="text--base">
                                                <?php echo e($general->cur_sym.showAmount($remainingAmount)); ?> <?php echo app('translator')->get('Remaining'); ?>
                                            </small>
                                        </span>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                        <?php if($loan->status == 0): ?>
                                            <span class="badge badge--warning"><?php echo app('translator')->get('Requested'); ?></span>
                                        <?php elseif($loan->status == 1): ?>
                                            <span class="badge badge--info"><?php echo app('translator')->get('Running'); ?></span>
                                        <?php elseif($loan->status == 2): ?>
                                            <span class="badge badge--success"><?php echo app('translator')->get('Paid'); ?></span>

                                        <?php elseif($loan->status == 3): ?>
                                            <span class="badge badge--danger"><?php echo app('translator')->get('Rejected'); ?></span>
                                            <span class="admin-feedback" data-feedback="<?php echo e(__($loan->admin_feedback)); ?>"><i class="fas fa-info-circle"></i></span>
                                        <?php endif; ?>
                                    </td>


                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                        <?php echo e($loans->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- dashboard section end -->
    <?php $__env->startPush('modal'); ?>
    <div class="modal fade" id="closeFdr" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <strong class="modal-title"><?php echo app('translator')->get('Confirmation Alert'); ?>!</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </a>
                </div>
                <form action="<?php echo e(route('user.fdr.close')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_token" required>
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="hidden" name="id" class="transferId" required>
                        </div>
                        <div class="content">
                          <p><?php echo app('translator')->get('Are You Sure To Close This Investment'); ?>?</p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-md btn--danger text-white" data-bs-dismiss="modal"><?php echo app('translator')->get('No'); ?></button>
                        <button type="submit" class="btn btn-md custom--bg text-white"><?php echo app('translator')->get('Yes'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="adminFeedback">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <strong class="modal-title"><?php echo app('translator')->get('Reason of Rejection'); ?>!</strong>
                </div>
                <div class="modal-body">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-md btn--danger text-white" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function($){
            "use strict";
            $('.closeBtn').on('click', function() {
                var modal = $('#closeFdr');
                modal.find('input[name=user_token]').val($(this).data('token'));
                modal.modal('show');
            });

            $('.admin-feedback').on('click', function(){
                var modal = $('#adminFeedback');

                console.log($(this).data('feedback'));

                modal.find('.modal-body').text($(this).data('feedback'));
                modal.modal('show');
            });

        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('bottom-menu'); ?>
    <li>
        <a href="<?php echo e(route('user.loan.plans')); ?>"><?php echo app('translator')->get('Loan Plans'); ?></a>
    </li>
    <li>
        <a href="<?php echo e(route('user.loan.list')); ?>" class="active"><?php echo app('translator')->get('My Loan List'); ?></a>
    </li>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/user/loan/list.blade.php ENDPATH**/ ?>