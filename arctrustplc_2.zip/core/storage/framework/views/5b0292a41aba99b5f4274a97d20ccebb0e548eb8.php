    <!-- header-section start  -->
    <header class="header">
        <div class="header__bottom">
          <div class="container">
            <nav class="navbar navbar-expand-lg p-0 align-items-center justify-content-between">
              <a class="site-logo site-title" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="logo">
            </a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="menu-toggle"></span>
              </button>
            <div class="collapse navbar-collapse mt-xl-0 mt-3" id="navbarSupportedContent">
                <ul class="navbar-nav main-menu m-auto" id="linkItem">
                  <li><a class="<?php echo e(menuActive('home')); ?>" href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a class="<?php if($data->slug ==  Request::segment(1)): ?> active <?php endif; ?>" href="<?php echo e(route('pages',[$data->slug])); ?>">
                                <?php echo e(__($data->name)); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li><a class="<?php echo e(menuActive('contact')); ?>" href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
                </ul>
                <div class="nav-right">
                    <select class="language-select me-3 langSel">
                        <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->code); ?>" <?php if(session('lang') == $item->code): ?> selected  <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php if(!Auth::user()): ?>
                        <a href="<?php echo e(route('user.login')); ?>" class="btn btn-sm py-2 btn-outline--gradient me-3"><?php echo app('translator')->get('Sign In'); ?></a>
                        <a href="<?php echo e(route('user.register')); ?>" class="btn btn-sm py-2 custom--bg text-white"><?php echo app('translator')->get('Sign Up'); ?></a>
                    <?php else: ?>
                        <a href="<?php echo e(route('user.home')); ?>" class="btn btn-sm py-2 btn-outline--gradient me-3"><?php echo app('translator')->get('Dashboard'); ?></a>
                        <a href="<?php echo e(route('user.logout')); ?>" class="btn btn-sm py-2 custom--bg text-white"><?php echo app('translator')->get('Logout'); ?></a>
                    <?php endif; ?>

                </div>
              </div>
            </nav>
          </div>
        </div><!-- header__bottom end -->
      </header>
      <!-- header-section end  -->
<?php /**PATH /home/trustspr/public_html/core/resources/views/templates/basic/partials/header.blade.php ENDPATH**/ ?>